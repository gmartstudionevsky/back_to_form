import { AppData } from '../types';

export const schemaVersion = 14;

export const seedData: AppData = {
  schemaVersion,
  library: {
    exercises: [
      {
        id: 'ex-chin-tuck',
        name: 'Втягивание подбородка',
        tags: ['шея'],
        steps: ['Сядьте ровно.', 'Мягко втяните подбородок назад.', 'Держите 5–10 секунд.'],
        cues: ['Шея длинная', 'Плечи расслаблены'],
        mistakes: ['Поднятые плечи', 'Резкий рывок'],
        regressions: ['Сделать у стены'],
        progressions: ['Добавить лёгкое сопротивление'],
        activityMetrics: { perMinute: 0.04, base: 0.2 }
      },
      {
        id: 'ex-neck-side-bend',
        name: 'Наклон шеи в сторону',
        tags: ['шея'],
        steps: ['Наклоните голову к плечу.', 'Держите 15–20 секунд.'],
        cues: ['Плечи вниз'],
        mistakes: ['Крутить головой'],
        regressions: ['Меньше амплитуда'],
        progressions: ['Лёгкое давление рукой'],
        activityMetrics: { perMinute: 0.04, base: 0.2 }
      },
      {
        id: 'ex-open-book',
        name: 'Поворот грудного отдела «Книга»',
        tags: ['грудной отдел'],
        steps: ['Лягте на бок.', 'Откройте грудную клетку вверх.', 'Дышите глубоко.'],
        cues: ['Колени вместе'],
        mistakes: ['Отрыв коленей'],
        regressions: ['Меньше амплитуда'],
        progressions: ['Дольше удержание'],
        activityMetrics: { perMinute: 0.04, base: 0.2 }
      },
      {
        id: 'ex-cat-cow',
        name: 'Кошка-корова',
        tags: ['спина'],
        steps: ['Встаньте на четвереньки.', 'Плавно прогибайте и округляйте спину.'],
        cues: ['Движение мягкое'],
        mistakes: ['Задержка дыхания'],
        regressions: ['Сидя на стуле'],
        progressions: ['Добавить паузу'],
        activityMetrics: { perMinute: 0.04, base: 0.2 }
      },
      {
        id: 'ex-hip-flexor',
        name: 'Растяжка сгибателей бедра',
        tags: ['таз'],
        steps: ['Полуколено.', 'Подайте таз вперёд.', 'Держите 20–30 сек.'],
        cues: ['Корпус ровный'],
        mistakes: ['Прогиб в пояснице'],
        regressions: ['Меньше шаг'],
        progressions: ['Поднять руку вверх'],
        activityMetrics: { perMinute: 0.04, base: 0.2 }
      },
      {
        id: 'ex-glute-bridge',
        name: 'Ягодичный мостик',
        tags: ['ягодицы'],
        steps: ['Лёжа на спине.', 'Поднимите таз.', 'Сожмите ягодицы.'],
        cues: ['Рёбра вниз'],
        mistakes: ['Переразгиб'],
        regressions: ['Меньше амплитуда'],
        progressions: ['Одна нога'],
        activityMetrics: { perMinute: 0.04, base: 0.25 }
      },
      {
        id: 'ex-bird-dog',
        name: 'Птица-собака',
        tags: ['стабилизация'],
        steps: ['Рука и нога в линию.', 'Держите 3–5 сек.'],
        cues: ['Таз стабилен'],
        mistakes: ['Провал в пояснице'],
        regressions: ['По отдельности'],
        progressions: ['Дольше удержание'],
        activityMetrics: { perMinute: 0.04, base: 0.25 }
      },
      {
        id: 'ex-ankle-wall',
        name: 'Мобилизация голеностопа у стены',
        tags: ['голеностоп'],
        steps: ['Колено к стене.', 'Пятка на полу.'],
        cues: ['Контроль'],
        mistakes: ['Отрыв пятки'],
        regressions: ['Меньше дистанция'],
        progressions: ['Дальше от стены'],
        activityMetrics: { perMinute: 0.04, base: 0.2 }
      },
      {
        id: 'ex-chair-squat',
        name: 'Присед на короб',
        tags: ['ноги'],
        steps: ['Сядьте на короб.', 'Встаньте без рывка.'],
        cues: ['Колени наружу'],
        mistakes: ['Падение на стул'],
        regressions: ['Выше короб'],
        progressions: ['Без коробки'],
        activityMetrics: { perMinute: 0.05, base: 0.3 }
      },
      {
        id: 'ex-incline-pushup',
        name: 'Отжимания от опоры',
        tags: ['грудь'],
        steps: ['Упритесь в стол или стену.', 'Опускайтесь контролируемо.'],
        cues: ['Корпус прямой'],
        mistakes: ['Прогиб'],
        regressions: ['Выше опора'],
        progressions: ['Ниже опора'],
        activityMetrics: { perMinute: 0.05, base: 0.3 }
      },
      {
        id: 'ex-backpack-row',
        name: 'Тяга рюкзака',
        tags: ['спина'],
        steps: ['Тяните рюкзак к поясу.', 'Пауза вверху.'],
        cues: ['Лопатки назад'],
        mistakes: ['Круглая спина'],
        regressions: ['Лёгкий вес'],
        progressions: ['Тяжелее вес'],
        activityMetrics: { perMinute: 0.05, base: 0.3 }
      },
      {
        id: 'ex-dead-bug',
        name: 'Мёртвый жук',
        tags: ['кор'],
        steps: ['Спина прижата.', 'Плавно опускайте руку/ногу.'],
        cues: ['Поясница на полу'],
        mistakes: ['Прогиб'],
        regressions: ['Только руки'],
        progressions: ['Дольше удержание'],
        activityMetrics: { perMinute: 0.04, base: 0.25 }
      },
      {
        id: 'ex-knee-plank',
        name: 'Планка с колен',
        tags: ['кор'],
        steps: ['Колени на полу.', 'Держите 20–30 сек.'],
        cues: ['Рёбра вниз'],
        mistakes: ['Провис'],
        regressions: ['Меньше время'],
        progressions: ['Полная планка'],
        activityMetrics: { perMinute: 0.04, base: 0.25 }
      },
      {
        id: 'ex-mcgill',
        name: 'Скручивание МакГилла',
        tags: ['кор'],
        steps: ['Одна нога согнута.', 'Небольшой подъём головы и плеч.'],
        cues: ['Шея нейтрально'],
        mistakes: ['Сильный подъём'],
        regressions: ['Меньше время'],
        progressions: ['Дольше удержание'],
        activityMetrics: { perMinute: 0.04, base: 0.25 }
      }
    ],
    protocols: [
      {
        id: 'proto-r10-warmup',
        name: 'Разминка R10',
        description: 'Разминка 10 минут с мягкой мобилизацией.',
        steps: [
          { text: 'Втягивание подбородка', durationSec: 30, exerciseRef: 'ex-chin-tuck' },
          { text: 'Наклон шеи в сторону', durationSec: 60, exerciseRef: 'ex-neck-side-bend' },
          { text: 'Поворот грудного отдела', durationSec: 60, exerciseRef: 'ex-open-book' },
          { text: 'Кошка-корова', durationSec: 60, exerciseRef: 'ex-cat-cow' },
          { text: 'Сгибатели бедра', durationSec: 60, exerciseRef: 'ex-hip-flexor' },
          { text: 'Ягодичный мостик', durationSec: 60, exerciseRef: 'ex-glute-bridge' },
          { text: 'Птица-собака', durationSec: 60, exerciseRef: 'ex-bird-dog' },
          { text: 'Голеностоп у стены', durationSec: 60, exerciseRef: 'ex-ankle-wall' }
        ]
      },
      {
        id: 'proto-s0-str',
        name: 'Силовой круг S0',
        description: 'Круговая тренировка, 2 круга. Контроль темпа, отдых 60 сек.',
        steps: [
          { text: 'Присед на короб x8', exerciseRef: 'ex-chair-squat' },
          { text: 'Отжимания от опоры x8', exerciseRef: 'ex-incline-pushup' },
          { text: 'Тяга рюкзака x10', exerciseRef: 'ex-backpack-row' },
          { text: 'Мёртвый жук x8/стор', exerciseRef: 'ex-dead-bug' },
          { text: 'Планка с колен 20 сек', exerciseRef: 'ex-knee-plank' },
          { text: 'Скручивание МакГилла x6/стор', exerciseRef: 'ex-mcgill' }
        ]
      }
    ],
    products: [
      {
        id: 'prod-chicken-thighs',
        name: 'Куриные бёдра (сырые, approx)',
        kcalPer100g: 185,
        proteinPer100g: 18,
        fatPer100g: 12,
        portionPresets: [{ label: '1 порция', grams: 180 }]
      },
      {
        id: 'prod-fish',
        name: 'Рыба (сырая, approx)',
        kcalPer100g: 120,
        proteinPer100g: 20,
        fatPer100g: 4,
        portionPresets: [{ label: '1 порция', grams: 160 }]
      },
      {
        id: 'prod-turkey-mince',
        name: 'Фарш индейки (approx)',
        kcalPer100g: 150,
        proteinPer100g: 19,
        fatPer100g: 8
      },
      {
        id: 'prod-eggs',
        name: 'Яйца (approx)',
        kcalPer100g: 143,
        proteinPer100g: 13,
        fatPer100g: 10,
        portionPresets: [{ label: '3 яйца', grams: 150 }],
        pieceGrams: 50,
        pieceLabel: 'шт.'
      },
      {
        id: 'prod-greek-yogurt',
        name: 'Греческий йогурт (approx)',
        kcalPer100g: 97,
        proteinPer100g: 9,
        fatPer100g: 5,
        carbPer100g: 4,
        nutritionTags: ['snack', 'healthy'],
        portionPresets: [{ label: '1 стакан', grams: 200 }],
        hydrationContribution: true,
        notes: 'Подходит для быстрого перекуса.'
      },
      {
        id: 'prod-cottage',
        name: 'Творог (approx)',
        kcalPer100g: 120,
        proteinPer100g: 16,
        fatPer100g: 5,
        carbPer100g: 3,
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-kefir',
        name: 'Кефир (approx)',
        kcalPer100g: 60,
        proteinPer100g: 3,
        fatPer100g: 3,
        carbPer100g: 4,
        nutritionTags: ['snack', 'healthy'],
        portionPresets: [{ label: '250 мл', grams: 250 }],
        hydrationContribution: true
      },
      {
        id: 'prod-rice',
        name: 'Рис (сухой, approx)',
        kcalPer100g: 360,
        proteinPer100g: 7,
        fatPer100g: 1,
        carbPer100g: 80,
        nutritionTags: ['healthy'],
        portionPresets: [{ label: '50 г сухого', grams: 50 }]
      },
      {
        id: 'prod-buckwheat',
        name: 'Гречка (сухая, approx)',
        kcalPer100g: 340,
        proteinPer100g: 12,
        fatPer100g: 3,
        carbPer100g: 68,
        nutritionTags: ['healthy'],
        portionPresets: [{ label: '60 г сухого', grams: 60 }]
      },
      {
        id: 'prod-potatoes',
        name: 'Картофель (approx)',
        kcalPer100g: 77,
        proteinPer100g: 2,
        carbPer100g: 17,
        portionPresets: [{ label: '200 г', grams: 200 }]
      },
      {
        id: 'prod-cucumber',
        name: 'Огурец (approx)',
        kcalPer100g: 15
      },
      {
        id: 'prod-tomato',
        name: 'Помидор (approx)',
        kcalPer100g: 18
      },
      {
        id: 'prod-lettuce',
        name: 'Салат листовой (approx)',
        kcalPer100g: 15
      },
      {
        id: 'prod-onion',
        name: 'Лук (approx)',
        kcalPer100g: 40
      },
      {
        id: 'prod-carrot',
        name: 'Морковь (approx)',
        kcalPer100g: 41
      },
      {
        id: 'prod-bell-pepper',
        name: 'Перец болгарский (approx)',
        kcalPer100g: 26
      },
      {
        id: 'prod-zucchini',
        name: 'Кабачок (approx)',
        kcalPer100g: 17
      },
      {
        id: 'prod-broccoli',
        name: 'Брокколи (замороженная, approx)',
        kcalPer100g: 35
      },
      {
        id: 'prod-banana',
        name: 'Банан (approx)',
        kcalPer100g: 89,
        nutritionTags: ['snack'],
        portionPresets: [{ label: '1 банан', grams: 120 }],
        pieceGrams: 120,
        pieceLabel: 'шт.'
      },
      {
        id: 'prod-apple',
        name: 'Яблоко (approx)',
        kcalPer100g: 52,
        nutritionTags: ['snack', 'healthy'],
        portionPresets: [{ label: '1 яблоко', grams: 150 }],
        hydrationContribution: true,
        pieceGrams: 150,
        pieceLabel: 'шт.'
      },
      {
        id: 'prod-oats',
        name: 'Овсянка (сухая, approx)',
        kcalPer100g: 370,
        proteinPer100g: 13,
        fatPer100g: 6,
        carbPer100g: 62,
        nutritionTags: ['healthy'],
        portionPresets: [{ label: '40 г', grams: 40 }],
        notes: 'База для каши или батончиков.'
      },
      {
        id: 'prod-honey',
        name: 'Мёд (approx)',
        kcalPer100g: 304,
        carbPer100g: 82,
        nutritionTags: ['snack'],
        portionPresets: [{ label: '1 ч.л.', grams: 12 }]
      },
      {
        id: 'prod-dark-chocolate',
        name: 'Тёмный шоколад (approx)',
        kcalPer100g: 540,
        fatPer100g: 30,
        carbPer100g: 50,
        nutritionTags: ['cheat', 'snack'],
        portionPresets: [{ label: '20 г', grams: 20 }],
        notes: 'Использовать как читмил.'
      },
      {
        id: 'prod-olive-oil',
        name: 'Оливковое масло (approx)',
        kcalPer100g: 884,
        fatPer100g: 100,
        portionPresets: [{ label: '1 ст.л.', grams: 14 }]
      },
      {
        id: 'prod-chicken-breast',
        name: 'Куриная грудка (сырая, approx)',
        kcalPer100g: 165,
        proteinPer100g: 31,
        fatPer100g: 4,
        carbPer100g: 0,
        portionPresets: [{ label: '1 порция', grams: 180 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-chicken-fillet-roasted',
        name: 'Куриное филе (готовое, approx)',
        kcalPer100g: 155,
        proteinPer100g: 29,
        fatPer100g: 3.5,
        carbPer100g: 0,
        portionPresets: [{ label: '1 порция', grams: 180 }],
        nutritionTags: ['healthy'],
        notes: 'Значения усреднены для готового продукта.'
      },
      {
        id: 'prod-turkey-breast',
        name: 'Индейка (грудка, сырая, approx)',
        kcalPer100g: 135,
        proteinPer100g: 29,
        fatPer100g: 2,
        carbPer100g: 0,
        portionPresets: [{ label: '1 порция', grams: 180 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-beef-lean',
        name: 'Говядина постная (сырое, approx)',
        kcalPer100g: 170,
        proteinPer100g: 24,
        fatPer100g: 8,
        carbPer100g: 0,
        portionPresets: [{ label: '1 порция', grams: 170 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-beef-mince-5',
        name: 'Фарш говяжий 5% (approx)',
        kcalPer100g: 140,
        proteinPer100g: 21,
        fatPer100g: 5,
        carbPer100g: 0,
        portionPresets: [{ label: '1 порция', grams: 180 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-veal-lean',
        name: 'Телятина постная (сырая, approx)',
        kcalPer100g: 150,
        proteinPer100g: 23,
        fatPer100g: 6,
        carbPer100g: 0,
        portionPresets: [{ label: '1 порция', grams: 170 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-pork-tenderloin',
        name: 'Свиная вырезка (сырая, approx)',
        kcalPer100g: 143,
        proteinPer100g: 21,
        fatPer100g: 6,
        carbPer100g: 0,
        portionPresets: [{ label: '1 порция', grams: 170 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-rabbit',
        name: 'Кролик (мясо, сырое, approx)',
        kcalPer100g: 173,
        proteinPer100g: 21,
        fatPer100g: 9,
        carbPer100g: 0,
        portionPresets: [{ label: '1 порция', grams: 170 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-chicken-liver',
        name: 'Печень куриная (сырая, approx)',
        kcalPer100g: 137,
        proteinPer100g: 20,
        fatPer100g: 6,
        carbPer100g: 0.7,
        portionPresets: [{ label: '1 порция', grams: 150 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-beef-liver',
        name: 'Печень говяжья (сырая, approx)',
        kcalPer100g: 135,
        proteinPer100g: 20,
        fatPer100g: 3.6,
        carbPer100g: 4,
        portionPresets: [{ label: '1 порция', grams: 150 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-salmon',
        name: 'Лосось/семга (сырая, approx)',
        kcalPer100g: 208,
        proteinPer100g: 20,
        fatPer100g: 13,
        carbPer100g: 0,
        portionPresets: [{ label: '1 порция', grams: 160 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-trout',
        name: 'Форель (сырая, approx)',
        kcalPer100g: 190,
        proteinPer100g: 20,
        fatPer100g: 12,
        carbPer100g: 0,
        portionPresets: [{ label: '1 порция', grams: 160 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-cod',
        name: 'Треска (сырая, approx)',
        kcalPer100g: 82,
        proteinPer100g: 18,
        fatPer100g: 0.7,
        carbPer100g: 0,
        portionPresets: [{ label: '1 порция', grams: 180 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-hake',
        name: 'Хек (сырой, approx)',
        kcalPer100g: 86,
        proteinPer100g: 17,
        fatPer100g: 2,
        carbPer100g: 0,
        portionPresets: [{ label: '1 порция', grams: 180 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-pollock',
        name: 'Минтай (сырой, approx)',
        kcalPer100g: 72,
        proteinPer100g: 16,
        fatPer100g: 0.9,
        carbPer100g: 0,
        portionPresets: [{ label: '1 порция', grams: 180 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-tuna-canned-water',
        name: 'Тунец консервированный в собственном соку (approx)',
        kcalPer100g: 110,
        proteinPer100g: 24,
        fatPer100g: 1,
        carbPer100g: 0,
        portionPresets: [{ label: '1 банка (нетто)', grams: 130 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-sardines',
        name: 'Сардины (консервы, approx)',
        kcalPer100g: 180,
        proteinPer100g: 20,
        fatPer100g: 11,
        carbPer100g: 0,
        portionPresets: [{ label: '1 банка (нетто)', grams: 120 }],
        nutritionTags: ['healthy'],
        notes: 'Зависит от заливки (вода/масло).'
      },
      {
        id: 'prod-mackerel',
        name: 'Скумбрия (сырая, approx)',
        kcalPer100g: 205,
        proteinPer100g: 19,
        fatPer100g: 14,
        carbPer100g: 0,
        portionPresets: [{ label: '1 порция', grams: 160 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-shrimp',
        name: 'Креветки (варёные/очищенные, approx)',
        kcalPer100g: 99,
        proteinPer100g: 24,
        fatPer100g: 0.3,
        carbPer100g: 0.2,
        portionPresets: [{ label: '1 порция', grams: 150 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-mussels',
        name: 'Мидии (мясо, approx)',
        kcalPer100g: 90,
        proteinPer100g: 12,
        fatPer100g: 2.5,
        carbPer100g: 3.5,
        portionPresets: [{ label: '1 порция', grams: 150 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-squid',
        name: 'Кальмар (филе, approx)',
        kcalPer100g: 92,
        proteinPer100g: 16,
        fatPer100g: 1,
        carbPer100g: 3,
        portionPresets: [{ label: '1 порция', grams: 160 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-egg-whites',
        name: 'Яичный белок (approx)',
        kcalPer100g: 52,
        proteinPer100g: 11,
        fatPer100g: 0.2,
        carbPer100g: 0.7,
        hydrationContribution: true,
        portionPresets: [{ label: '200 г', grams: 200 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-milk-15',
        name: 'Молоко 1.5% (approx)',
        kcalPer100g: 45,
        proteinPer100g: 3.2,
        fatPer100g: 1.5,
        carbPer100g: 4.7,
        hydrationContribution: true,
        portionPresets: [{ label: '250 мл', grams: 250 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-milk-32',
        name: 'Молоко 3.2% (approx)',
        kcalPer100g: 60,
        proteinPer100g: 3.2,
        fatPer100g: 3.2,
        carbPer100g: 4.7,
        hydrationContribution: true,
        portionPresets: [{ label: '250 мл', grams: 250 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-skyr',
        name: 'Скир/Skyr (натуральный, approx)',
        kcalPer100g: 60,
        proteinPer100g: 11,
        fatPer100g: 0.2,
        carbPer100g: 3.5,
        hydrationContribution: true,
        portionPresets: [{ label: '1 баночка', grams: 150 }],
        nutritionTags: ['healthy', 'snack']
      },
      {
        id: 'prod-yogurt-natural',
        name: 'Йогурт натуральный без сахара (approx)',
        kcalPer100g: 63,
        proteinPer100g: 5,
        fatPer100g: 3,
        carbPer100g: 5,
        hydrationContribution: true,
        portionPresets: [{ label: '200 г', grams: 200 }],
        nutritionTags: ['healthy', 'snack']
      },
      {
        id: 'prod-cottage-2',
        name: 'Творог 2% (approx)',
        kcalPer100g: 85,
        proteinPer100g: 18,
        fatPer100g: 2,
        carbPer100g: 3,
        portionPresets: [{ label: '200 г', grams: 200 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-ricotta',
        name: 'Рикотта (approx)',
        kcalPer100g: 174,
        proteinPer100g: 11,
        fatPer100g: 13,
        carbPer100g: 3,
        portionPresets: [{ label: '100 г', grams: 100 }],
        nutritionTags: ['healthy'],
        notes: 'Состав зависит от бренда.'
      },
      {
        id: 'prod-mozzarella-light',
        name: 'Моцарелла (лайт, approx)',
        kcalPer100g: 200,
        proteinPer100g: 22,
        fatPer100g: 12,
        carbPer100g: 2,
        portionPresets: [{ label: '80 г', grams: 80 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-hard-cheese',
        name: 'Сыр твёрдый (approx)',
        kcalPer100g: 350,
        proteinPer100g: 25,
        fatPer100g: 28,
        carbPer100g: 0.5,
        portionPresets: [{ label: '30 г', grams: 30 }],
        nutritionTags: ['healthy'],
        notes: 'Усреднённо для твёрдых сыров.'
      },
      {
        id: 'prod-sour-cream-10',
        name: 'Сметана 10% (approx)',
        kcalPer100g: 115,
        proteinPer100g: 3,
        fatPer100g: 10,
        carbPer100g: 3.5,
        portionPresets: [{ label: '1 ст.л.', grams: 20 }],
        nutritionTags: ['healthy'],
        notes: 'Использовать как добавку.'
      },
      {
        id: 'prod-whey-protein',
        name: 'Сывороточный протеин (порошок, approx)',
        kcalPer100g: 400,
        proteinPer100g: 80,
        fatPer100g: 6,
        carbPer100g: 8,
        portionPresets: [{ label: '1 мерная ложка', grams: 30 }],
        nutritionTags: ['healthy'],
        notes: 'Зависит от бренда.'
      },
      {
        id: 'prod-casein-protein',
        name: 'Казеин (порошок, approx)',
        kcalPer100g: 380,
        proteinPer100g: 75,
        fatPer100g: 2,
        carbPer100g: 10,
        portionPresets: [{ label: '1 мерная ложка', grams: 30 }],
        nutritionTags: ['healthy'],
        notes: 'Зависит от бренда.'
      },
      {
        id: 'prod-tofu-firm',
        name: 'Тофу (плотный, approx)',
        kcalPer100g: 120,
        proteinPer100g: 13,
        fatPer100g: 7,
        carbPer100g: 2,
        portionPresets: [{ label: '150 г', grams: 150 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-tempeh',
        name: 'Темпе (approx)',
        kcalPer100g: 190,
        proteinPer100g: 20,
        fatPer100g: 11,
        carbPer100g: 9,
        portionPresets: [{ label: '150 г', grams: 150 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-lentils-red-dry',
        name: 'Чечевица красная (сухая, approx)',
        kcalPer100g: 340,
        proteinPer100g: 25,
        fatPer100g: 1.5,
        carbPer100g: 60,
        portionPresets: [{ label: '60 г сухого', grams: 60 }],
        nutritionTags: ['healthy'],
        notes: 'Значения для сухого продукта.'
      },
      {
        id: 'prod-lentils-green-dry',
        name: 'Чечевица зелёная (сухая, approx)',
        kcalPer100g: 330,
        proteinPer100g: 24,
        fatPer100g: 1.3,
        carbPer100g: 60,
        portionPresets: [{ label: '60 г сухого', grams: 60 }],
        nutritionTags: ['healthy'],
        notes: 'Значения для сухого продукта.'
      },
      {
        id: 'prod-chickpeas-dry',
        name: 'Нут (сухой, approx)',
        kcalPer100g: 364,
        proteinPer100g: 19,
        fatPer100g: 6,
        carbPer100g: 61,
        portionPresets: [{ label: '60 г сухого', grams: 60 }],
        nutritionTags: ['healthy'],
        notes: 'Значения для сухого продукта.'
      },
      {
        id: 'prod-beans-kidney-dry',
        name: 'Фасоль красная (сухая, approx)',
        kcalPer100g: 330,
        proteinPer100g: 23,
        fatPer100g: 1.2,
        carbPer100g: 60,
        portionPresets: [{ label: '60 г сухого', grams: 60 }],
        nutritionTags: ['healthy'],
        notes: 'Значения для сухого продукта.'
      },
      {
        id: 'prod-beans-white-dry',
        name: 'Фасоль белая (сухая, approx)',
        kcalPer100g: 330,
        proteinPer100g: 23,
        fatPer100g: 1.2,
        carbPer100g: 60,
        portionPresets: [{ label: '60 г сухого', grams: 60 }],
        nutritionTags: ['healthy'],
        notes: 'Значения для сухого продукта.'
      },
      {
        id: 'prod-peas-dry',
        name: 'Горох (сухой, approx)',
        kcalPer100g: 320,
        proteinPer100g: 20,
        fatPer100g: 2,
        carbPer100g: 55,
        portionPresets: [{ label: '60 г сухого', grams: 60 }],
        nutritionTags: ['healthy'],
        notes: 'Значения для сухого продукта.'
      },
      {
        id: 'prod-edamame',
        name: 'Эдамаме (замороженные, approx)',
        kcalPer100g: 120,
        proteinPer100g: 11,
        fatPer100g: 5,
        carbPer100g: 9,
        portionPresets: [{ label: '150 г', grams: 150 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-rice-brown',
        name: 'Рис бурый (сухой, approx)',
        kcalPer100g: 360,
        proteinPer100g: 7.5,
        fatPer100g: 2.5,
        carbPer100g: 76,
        portionPresets: [{ label: '50 г сухого', grams: 50 }],
        nutritionTags: ['healthy'],
        notes: 'Значения для сухого продукта.'
      },
      {
        id: 'prod-rice-basmati',
        name: 'Рис басмати (сухой, approx)',
        kcalPer100g: 360,
        proteinPer100g: 7,
        fatPer100g: 1,
        carbPer100g: 79,
        portionPresets: [{ label: '50 г сухого', grams: 50 }],
        nutritionTags: ['healthy'],
        notes: 'Значения для сухого продукта.'
      },
      {
        id: 'prod-quinoa-dry',
        name: 'Киноа (сухая, approx)',
        kcalPer100g: 368,
        proteinPer100g: 14,
        fatPer100g: 6,
        carbPer100g: 64,
        portionPresets: [{ label: '50 г сухого', grams: 50 }],
        nutritionTags: ['healthy'],
        notes: 'Значения для сухого продукта.'
      },
      {
        id: 'prod-barley-dry',
        name: 'Перловка (сухая, approx)',
        kcalPer100g: 352,
        proteinPer100g: 10,
        fatPer100g: 1.2,
        carbPer100g: 73,
        portionPresets: [{ label: '60 г сухого', grams: 60 }],
        nutritionTags: ['healthy'],
        notes: 'Значения для сухого продукта.'
      },
      {
        id: 'prod-bulgur-dry',
        name: 'Булгур (сухой, approx)',
        kcalPer100g: 342,
        proteinPer100g: 12,
        fatPer100g: 1.3,
        carbPer100g: 76,
        portionPresets: [{ label: '60 г сухого', grams: 60 }],
        nutritionTags: ['healthy'],
        notes: 'Значения для сухого продукта.'
      },
      {
        id: 'prod-couscous-dry',
        name: 'Кускус (сухой, approx)',
        kcalPer100g: 376,
        proteinPer100g: 13,
        fatPer100g: 0.6,
        carbPer100g: 77,
        portionPresets: [{ label: '60 г сухого', grams: 60 }],
        nutritionTags: ['healthy'],
        notes: 'Значения для сухого продукта.'
      },
      {
        id: 'prod-pasta-durum-dry',
        name: 'Паста (из твёрдых сортов, сухая, approx)',
        kcalPer100g: 350,
        proteinPer100g: 12,
        fatPer100g: 1.5,
        carbPer100g: 72,
        portionPresets: [{ label: '70 г сухого', grams: 70 }],
        nutritionTags: ['healthy'],
        notes: 'Значения для сухого продукта.'
      },
      {
        id: 'prod-pasta-wholewheat-dry',
        name: 'Паста цельнозерновая (сухая, approx)',
        kcalPer100g: 340,
        proteinPer100g: 13,
        fatPer100g: 2.5,
        carbPer100g: 68,
        portionPresets: [{ label: '70 г сухого', grams: 70 }],
        nutritionTags: ['healthy'],
        notes: 'Значения для сухого продукта.'
      },
      {
        id: 'prod-bread-wholegrain',
        name: 'Хлеб цельнозерновой (approx)',
        kcalPer100g: 240,
        proteinPer100g: 9,
        fatPer100g: 4,
        carbPer100g: 45,
        portionPresets: [{ label: '1 ломтик', grams: 35 }],
        nutritionTags: ['healthy'],
        notes: 'Зависит от бренда.'
      },
      {
        id: 'prod-bread-rye',
        name: 'Хлеб ржаной (approx)',
        kcalPer100g: 210,
        proteinPer100g: 6,
        fatPer100g: 2,
        carbPer100g: 42,
        portionPresets: [{ label: '1 ломтик', grams: 35 }],
        nutritionTags: ['healthy'],
        notes: 'Зависит от бренда.'
      },
      {
        id: 'prod-tortilla-wholewheat',
        name: 'Тортилья цельнозерновая (approx)',
        kcalPer100g: 300,
        proteinPer100g: 9,
        fatPer100g: 7,
        carbPer100g: 50,
        portionPresets: [{ label: '1 шт.', grams: 60 }],
        pieceGrams: 60,
        pieceLabel: 'шт.',
        nutritionTags: ['healthy'],
        notes: 'Зависит от бренда.'
      },
      {
        id: 'prod-spinach',
        name: 'Шпинат (approx)',
        kcalPer100g: 23,
        hydrationContribution: true,
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-cabbage',
        name: 'Капуста белокочанная (approx)',
        kcalPer100g: 25,
        hydrationContribution: true,
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-red-cabbage',
        name: 'Капуста краснокочанная (approx)',
        kcalPer100g: 31,
        hydrationContribution: true,
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-cauliflower',
        name: 'Цветная капуста (approx)',
        kcalPer100g: 25,
        hydrationContribution: true,
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-mushrooms',
        name: 'Шампиньоны (approx)',
        kcalPer100g: 22,
        hydrationContribution: true,
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-garlic',
        name: 'Чеснок (approx)',
        kcalPer100g: 149,
        proteinPer100g: 6.4,
        fatPer100g: 0.5,
        carbPer100g: 33,
        portionPresets: [{ label: '1 зубчик', grams: 5 }],
        pieceGrams: 5,
        pieceLabel: 'шт.',
        nutritionTags: ['healthy'],
        notes: 'Обычно используется малыми дозами.'
      },
      {
        id: 'prod-beet',
        name: 'Свёкла (approx)',
        kcalPer100g: 43,
        hydrationContribution: true,
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-green-beans',
        name: 'Стручковая фасоль (approx)',
        kcalPer100g: 31,
        hydrationContribution: true,
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-green-peas',
        name: 'Горошек зелёный (approx)',
        kcalPer100g: 81,
        proteinPer100g: 5.4,
        fatPer100g: 0.4,
        carbPer100g: 14,
        hydrationContribution: true,
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-corn',
        name: 'Кукуруза (зерно, approx)',
        kcalPer100g: 96,
        proteinPer100g: 3.4,
        fatPer100g: 1.5,
        carbPer100g: 21,
        hydrationContribution: true,
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-pumpkin',
        name: 'Тыква (approx)',
        kcalPer100g: 26,
        hydrationContribution: true,
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-sweet-potato',
        name: 'Батат (approx)',
        kcalPer100g: 86,
        proteinPer100g: 1.6,
        fatPer100g: 0.1,
        carbPer100g: 20,
        hydrationContribution: true,
        portionPresets: [{ label: '200 г', grams: 200 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-eggplant',
        name: 'Баклажан (approx)',
        kcalPer100g: 25,
        hydrationContribution: true,
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-asparagus',
        name: 'Спаржа (approx)',
        kcalPer100g: 20,
        hydrationContribution: true,
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-celery-stalk',
        name: 'Сельдерей стеблевой (approx)',
        kcalPer100g: 16,
        hydrationContribution: true,
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-celery-root',
        name: 'Сельдерей корневой (approx)',
        kcalPer100g: 42,
        hydrationContribution: true,
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-radish',
        name: 'Редис (approx)',
        kcalPer100g: 16,
        hydrationContribution: true,
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-arugula',
        name: 'Руккола (approx)',
        kcalPer100g: 25,
        hydrationContribution: true,
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-kale',
        name: 'Кейл (листовая капуста, approx)',
        kcalPer100g: 49,
        proteinPer100g: 4.3,
        fatPer100g: 0.9,
        carbPer100g: 9,
        hydrationContribution: true,
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-dill',
        name: 'Укроп (approx)',
        kcalPer100g: 43,
        hydrationContribution: true,
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-parsley',
        name: 'Петрушка (approx)',
        kcalPer100g: 36,
        hydrationContribution: true,
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-cilantro',
        name: 'Кинза (approx)',
        kcalPer100g: 23,
        hydrationContribution: true,
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-lemon',
        name: 'Лимон (approx)',
        kcalPer100g: 29,
        hydrationContribution: true,
        portionPresets: [{ label: '1/2 лимона', grams: 60 }],
        pieceGrams: 120,
        pieceLabel: 'шт.',
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-lime',
        name: 'Лайм (approx)',
        kcalPer100g: 30,
        hydrationContribution: true,
        portionPresets: [{ label: '1 лайм', grams: 70 }],
        pieceGrams: 70,
        pieceLabel: 'шт.',
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-orange',
        name: 'Апельсин (approx)',
        kcalPer100g: 47,
        hydrationContribution: true,
        portionPresets: [{ label: '1 апельсин', grams: 180 }],
        pieceGrams: 180,
        pieceLabel: 'шт.',
        nutritionTags: ['healthy', 'snack']
      },
      {
        id: 'prod-mandarin',
        name: 'Мандарин (approx)',
        kcalPer100g: 53,
        hydrationContribution: true,
        portionPresets: [{ label: '2 мандарина', grams: 160 }],
        pieceGrams: 80,
        pieceLabel: 'шт.',
        nutritionTags: ['healthy', 'snack']
      },
      {
        id: 'prod-grapefruit',
        name: 'Грейпфрут (approx)',
        kcalPer100g: 42,
        hydrationContribution: true,
        portionPresets: [{ label: '1/2 грейпфрута', grams: 180 }],
        pieceGrams: 360,
        pieceLabel: 'шт.',
        nutritionTags: ['healthy', 'snack']
      },
      {
        id: 'prod-pear',
        name: 'Груша (approx)',
        kcalPer100g: 57,
        hydrationContribution: true,
        portionPresets: [{ label: '1 груша', grams: 170 }],
        pieceGrams: 170,
        pieceLabel: 'шт.',
        nutritionTags: ['healthy', 'snack']
      },
      {
        id: 'prod-peach',
        name: 'Персик (approx)',
        kcalPer100g: 39,
        hydrationContribution: true,
        portionPresets: [{ label: '1 персик', grams: 150 }],
        pieceGrams: 150,
        pieceLabel: 'шт.',
        nutritionTags: ['healthy', 'snack']
      },
      {
        id: 'prod-nectarine',
        name: 'Нектарин (approx)',
        kcalPer100g: 44,
        hydrationContribution: true,
        portionPresets: [{ label: '1 нектарин', grams: 150 }],
        pieceGrams: 150,
        pieceLabel: 'шт.',
        nutritionTags: ['healthy', 'snack']
      },
      {
        id: 'prod-apricot',
        name: 'Абрикос (approx)',
        kcalPer100g: 48,
        hydrationContribution: true,
        portionPresets: [{ label: '3 абрикоса', grams: 105 }],
        pieceGrams: 35,
        pieceLabel: 'шт.',
        nutritionTags: ['healthy', 'snack']
      },
      {
        id: 'prod-plum',
        name: 'Слива (approx)',
        kcalPer100g: 46,
        hydrationContribution: true,
        portionPresets: [{ label: '3 сливы', grams: 120 }],
        pieceGrams: 40,
        pieceLabel: 'шт.',
        nutritionTags: ['healthy', 'snack']
      },
      {
        id: 'prod-cherries',
        name: 'Черешня/вишня (approx)',
        kcalPer100g: 63,
        hydrationContribution: true,
        portionPresets: [{ label: '150 г', grams: 150 }],
        nutritionTags: ['healthy', 'snack']
      },
      {
        id: 'prod-strawberries',
        name: 'Клубника (approx)',
        kcalPer100g: 32,
        hydrationContribution: true,
        portionPresets: [{ label: '150 г', grams: 150 }],
        nutritionTags: ['healthy', 'snack']
      },
      {
        id: 'prod-blueberries',
        name: 'Черника/голубика (approx)',
        kcalPer100g: 57,
        hydrationContribution: true,
        portionPresets: [{ label: '150 г', grams: 150 }],
        nutritionTags: ['healthy', 'snack']
      },
      {
        id: 'prod-raspberries',
        name: 'Малина (approx)',
        kcalPer100g: 52,
        hydrationContribution: true,
        portionPresets: [{ label: '150 г', grams: 150 }],
        nutritionTags: ['healthy', 'snack']
      },
      {
        id: 'prod-blackberries',
        name: 'Ежевика (approx)',
        kcalPer100g: 43,
        hydrationContribution: true,
        portionPresets: [{ label: '150 г', grams: 150 }],
        nutritionTags: ['healthy', 'snack']
      },
      {
        id: 'prod-grapes',
        name: 'Виноград (approx)',
        kcalPer100g: 69,
        hydrationContribution: true,
        portionPresets: [{ label: '150 г', grams: 150 }],
        nutritionTags: ['healthy', 'snack']
      },
      {
        id: 'prod-kiwi',
        name: 'Киви (approx)',
        kcalPer100g: 61,
        hydrationContribution: true,
        portionPresets: [{ label: '2 киви', grams: 150 }],
        pieceGrams: 75,
        pieceLabel: 'шт.',
        nutritionTags: ['healthy', 'snack']
      },
      {
        id: 'prod-pineapple',
        name: 'Ананас (approx)',
        kcalPer100g: 50,
        hydrationContribution: true,
        portionPresets: [{ label: '200 г', grams: 200 }],
        nutritionTags: ['healthy', 'snack']
      },
      {
        id: 'prod-mango',
        name: 'Манго (approx)',
        kcalPer100g: 60,
        hydrationContribution: true,
        portionPresets: [{ label: '200 г', grams: 200 }],
        nutritionTags: ['healthy', 'snack']
      },
      {
        id: 'prod-melon',
        name: 'Дыня (approx)',
        kcalPer100g: 34,
        hydrationContribution: true,
        portionPresets: [{ label: '250 г', grams: 250 }],
        nutritionTags: ['healthy', 'snack']
      },
      {
        id: 'prod-watermelon',
        name: 'Арбуз (approx)',
        kcalPer100g: 30,
        hydrationContribution: true,
        portionPresets: [{ label: '300 г', grams: 300 }],
        nutritionTags: ['healthy', 'snack']
      },
      {
        id: 'prod-pomegranate',
        name: 'Гранат (зерна, approx)',
        kcalPer100g: 83,
        hydrationContribution: true,
        portionPresets: [{ label: '150 г', grams: 150 }],
        nutritionTags: ['healthy', 'snack']
      },
      {
        id: 'prod-dates',
        name: 'Финики (approx)',
        kcalPer100g: 282,
        proteinPer100g: 2.5,
        fatPer100g: 0.4,
        carbPer100g: 75,
        portionPresets: [{ label: '3 шт.', grams: 24 }],
        pieceGrams: 8,
        pieceLabel: 'шт.',
        nutritionTags: ['healthy', 'snack'],
        notes: 'Высокая сахаристость — учитывать порцию.'
      },
      {
        id: 'prod-raisins',
        name: 'Изюм (approx)',
        kcalPer100g: 299,
        proteinPer100g: 3,
        fatPer100g: 0.5,
        carbPer100g: 79,
        portionPresets: [{ label: '30 г', grams: 30 }],
        nutritionTags: ['healthy', 'snack'],
        notes: 'Высокая сахаристость — учитывать порцию.'
      },
      {
        id: 'prod-dried-apricots',
        name: 'Курага (approx)',
        kcalPer100g: 241,
        proteinPer100g: 3.4,
        fatPer100g: 0.5,
        carbPer100g: 63,
        portionPresets: [{ label: '30 г', grams: 30 }],
        nutritionTags: ['healthy', 'snack'],
        notes: 'Высокая сахаристость — учитывать порцию.'
      },
      {
        id: 'prod-almonds',
        name: 'Миндаль (approx)',
        kcalPer100g: 579,
        proteinPer100g: 21,
        fatPer100g: 50,
        carbPer100g: 22,
        portionPresets: [{ label: '30 г', grams: 30 }],
        nutritionTags: ['healthy', 'snack']
      },
      {
        id: 'prod-walnuts',
        name: 'Грецкие орехи (approx)',
        kcalPer100g: 654,
        proteinPer100g: 15,
        fatPer100g: 65,
        carbPer100g: 14,
        portionPresets: [{ label: '30 г', grams: 30 }],
        nutritionTags: ['healthy', 'snack']
      },
      {
        id: 'prod-cashews',
        name: 'Кешью (approx)',
        kcalPer100g: 553,
        proteinPer100g: 18,
        fatPer100g: 44,
        carbPer100g: 30,
        portionPresets: [{ label: '30 г', grams: 30 }],
        nutritionTags: ['healthy', 'snack']
      },
      {
        id: 'prod-hazelnuts',
        name: 'Фундук (approx)',
        kcalPer100g: 628,
        proteinPer100g: 15,
        fatPer100g: 61,
        carbPer100g: 17,
        portionPresets: [{ label: '30 г', grams: 30 }],
        nutritionTags: ['healthy', 'snack']
      },
      {
        id: 'prod-peanuts',
        name: 'Арахис (approx)',
        kcalPer100g: 567,
        proteinPer100g: 26,
        fatPer100g: 49,
        carbPer100g: 16,
        portionPresets: [{ label: '30 г', grams: 30 }],
        nutritionTags: ['healthy', 'snack']
      },
      {
        id: 'prod-pistachios',
        name: 'Фисташки (approx)',
        kcalPer100g: 562,
        proteinPer100g: 20,
        fatPer100g: 45,
        carbPer100g: 28,
        portionPresets: [{ label: '30 г', grams: 30 }],
        nutritionTags: ['healthy', 'snack']
      },
      {
        id: 'prod-sunflower-seeds',
        name: 'Семечки подсолнечника (approx)',
        kcalPer100g: 584,
        proteinPer100g: 20,
        fatPer100g: 52,
        carbPer100g: 20,
        portionPresets: [{ label: '20 г', grams: 20 }],
        nutritionTags: ['healthy', 'snack']
      },
      {
        id: 'prod-pumpkin-seeds',
        name: 'Семечки тыквенные (approx)',
        kcalPer100g: 559,
        proteinPer100g: 30,
        fatPer100g: 49,
        carbPer100g: 11,
        portionPresets: [{ label: '20 г', grams: 20 }],
        nutritionTags: ['healthy', 'snack']
      },
      {
        id: 'prod-chia',
        name: 'Семена чиа (approx)',
        kcalPer100g: 486,
        proteinPer100g: 17,
        fatPer100g: 31,
        carbPer100g: 42,
        portionPresets: [{ label: '1 ст.л.', grams: 12 }],
        nutritionTags: ['healthy', 'snack'],
        notes: 'Учитывать при добавлении в каши/йогурт.'
      },
      {
        id: 'prod-flax',
        name: 'Семена льна (approx)',
        kcalPer100g: 534,
        proteinPer100g: 18,
        fatPer100g: 42,
        carbPer100g: 29,
        portionPresets: [{ label: '1 ст.л.', grams: 10 }],
        nutritionTags: ['healthy', 'snack'],
        notes: 'Можно молоть для лучшей усвояемости.'
      },
      {
        id: 'prod-sesame',
        name: 'Кунжут (approx)',
        kcalPer100g: 573,
        proteinPer100g: 18,
        fatPer100g: 50,
        carbPer100g: 23,
        portionPresets: [{ label: '1 ст.л.', grams: 9 }],
        nutritionTags: ['healthy', 'snack']
      },
      {
        id: 'prod-peanut-butter',
        name: 'Арахисовая паста 100% (approx)',
        kcalPer100g: 590,
        proteinPer100g: 25,
        fatPer100g: 50,
        carbPer100g: 20,
        portionPresets: [{ label: '1 ст.л.', grams: 16 }],
        nutritionTags: ['healthy', 'snack'],
        notes: 'Без сахара/масел — учитывать калорийность.'
      },
      {
        id: 'prod-avocado',
        name: 'Авокадо (approx)',
        kcalPer100g: 160,
        proteinPer100g: 2,
        fatPer100g: 15,
        carbPer100g: 9,
        portionPresets: [{ label: '1/2 авокадо', grams: 100 }],
        pieceGrams: 200,
        pieceLabel: 'шт.',
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-olives',
        name: 'Оливки (approx)',
        kcalPer100g: 115,
        proteinPer100g: 0.8,
        fatPer100g: 10.7,
        carbPer100g: 6.3,
        portionPresets: [{ label: '10 шт.', grams: 40 }],
        pieceGrams: 4,
        pieceLabel: 'шт.',
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-avocado-oil',
        name: 'Масло авокадо (approx)',
        kcalPer100g: 884,
        proteinPer100g: 0,
        fatPer100g: 100,
        carbPer100g: 0,
        portionPresets: [{ label: '1 ст.л.', grams: 14 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-rapeseed-oil',
        name: 'Масло рапсовое (approx)',
        kcalPer100g: 884,
        proteinPer100g: 0,
        fatPer100g: 100,
        carbPer100g: 0,
        portionPresets: [{ label: '1 ст.л.', grams: 14 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-flaxseed-oil',
        name: 'Масло льняное (approx)',
        kcalPer100g: 884,
        proteinPer100g: 0,
        fatPer100g: 100,
        carbPer100g: 0,
        portionPresets: [{ label: '1 ст.л.', grams: 14 }],
        nutritionTags: ['healthy'],
        notes: 'Лучше не нагревать сильно.'
      },
      {
        id: 'prod-coconut-oil',
        name: 'Кокосовое масло (approx)',
        kcalPer100g: 892,
        proteinPer100g: 0,
        fatPer100g: 100,
        carbPer100g: 0,
        portionPresets: [{ label: '1 ст.л.', grams: 14 }],
        nutritionTags: ['healthy'],
        notes: 'Высокая доля насыщенных жиров — учитывать порцию.'
      },
      {
        id: 'prod-tahini',
        name: 'Тахини (кунжутная паста, approx)',
        kcalPer100g: 595,
        proteinPer100g: 17,
        fatPer100g: 53,
        carbPer100g: 21,
        portionPresets: [{ label: '1 ст.л.', grams: 15 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-salt',
        name: 'Соль (0 ккал)',
        kcalPer100g: 0,
        portionPresets: [{ label: '1 щепотка', grams: 1 }],
        nutritionTags: ['healthy'],
        notes: 'Используется малыми дозами.'
      },
      {
        id: 'prod-pepper-black',
        name: 'Перец чёрный молотый (approx)',
        kcalPer100g: 251,
        portionPresets: [{ label: '1 ч.л.', grams: 2 }],
        nutritionTags: ['healthy'],
        notes: 'Вклад калорий обычно пренебрежим.'
      },
      {
        id: 'prod-paprika',
        name: 'Паприка молотая (approx)',
        kcalPer100g: 282,
        portionPresets: [{ label: '1 ч.л.', grams: 2 }],
        nutritionTags: ['healthy'],
        notes: 'Вклад калорий обычно пренебрежим.'
      },
      {
        id: 'prod-turmeric',
        name: 'Куркума (approx)',
        kcalPer100g: 312,
        portionPresets: [{ label: '1 ч.л.', grams: 2 }],
        nutritionTags: ['healthy'],
        notes: 'Вклад калорий обычно пренебрежим.'
      },
      {
        id: 'prod-cumin',
        name: 'Зира/кумин (approx)',
        kcalPer100g: 375,
        portionPresets: [{ label: '1 ч.л.', grams: 2 }],
        nutritionTags: ['healthy'],
        notes: 'Вклад калорий обычно пренебрежим.'
      },
      {
        id: 'prod-coriander',
        name: 'Кориандр молотый (approx)',
        kcalPer100g: 298,
        portionPresets: [{ label: '1 ч.л.', grams: 2 }],
        nutritionTags: ['healthy'],
        notes: 'Вклад калорий обычно пренебрежим.'
      },
      {
        id: 'prod-cinnamon',
        name: 'Корица молотая (approx)',
        kcalPer100g: 247,
        portionPresets: [{ label: '1 ч.л.', grams: 2 }],
        nutritionTags: ['healthy'],
        notes: 'Вклад калорий обычно пренебрежим.'
      },
      {
        id: 'prod-oregano',
        name: 'Орегано сушёный (approx)',
        kcalPer100g: 265,
        portionPresets: [{ label: '1 ч.л.', grams: 1 }],
        nutritionTags: ['healthy'],
        notes: 'Вклад калорий обычно пренебрежим.'
      },
      {
        id: 'prod-basil-dried',
        name: 'Базилик сушёный (approx)',
        kcalPer100g: 233,
        portionPresets: [{ label: '1 ч.л.', grams: 1 }],
        nutritionTags: ['healthy'],
        notes: 'Вклад калорий обычно пренебрежим.'
      },
      {
        id: 'prod-thyme-dried',
        name: 'Тимьян сушёный (approx)',
        kcalPer100g: 276,
        portionPresets: [{ label: '1 ч.л.', grams: 1 }],
        nutritionTags: ['healthy'],
        notes: 'Вклад калорий обычно пренебрежим.'
      },
      {
        id: 'prod-rosemary-dried',
        name: 'Розмарин сушёный (approx)',
        kcalPer100g: 331,
        portionPresets: [{ label: '1 ч.л.', grams: 1 }],
        nutritionTags: ['healthy'],
        notes: 'Вклад калорий обычно пренебрежим.'
      },
      {
        id: 'prod-chili-flakes',
        name: 'Чили хлопья (approx)',
        kcalPer100g: 282,
        portionPresets: [{ label: '1 ч.л.', grams: 2 }],
        nutritionTags: ['healthy'],
        notes: 'Вклад калорий обычно пренебрежим.'
      },
      {
        id: 'prod-ginger-root',
        name: 'Имбирь (корень, approx)',
        kcalPer100g: 80,
        hydrationContribution: true,
        portionPresets: [{ label: '10 г', grams: 10 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-ginger-ground',
        name: 'Имбирь молотый (approx)',
        kcalPer100g: 335,
        portionPresets: [{ label: '1 ч.л.', grams: 2 }],
        nutritionTags: ['healthy'],
        notes: 'Вклад калорий обычно пренебрежим.'
      },
      {
        id: 'prod-garlic-powder',
        name: 'Чеснок сушёный/порошок (approx)',
        kcalPer100g: 331,
        portionPresets: [{ label: '1 ч.л.', grams: 3 }],
        nutritionTags: ['healthy'],
        notes: 'Вклад калорий обычно пренебрежим.'
      },
      {
        id: 'prod-soy-sauce',
        name: 'Соевый соус (approx)',
        kcalPer100g: 53,
        proteinPer100g: 8,
        fatPer100g: 0.6,
        carbPer100g: 4.9,
        hydrationContribution: true,
        portionPresets: [{ label: '1 ст.л.', grams: 15 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-vinegar-apple',
        name: 'Уксус яблочный (approx)',
        kcalPer100g: 21,
        hydrationContribution: true,
        portionPresets: [{ label: '1 ст.л.', grams: 15 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-vinegar-balsamic',
        name: 'Уксус бальзамический (approx)',
        kcalPer100g: 88,
        carbPer100g: 17,
        hydrationContribution: true,
        portionPresets: [{ label: '1 ст.л.', grams: 15 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-mustard',
        name: 'Горчица (approx)',
        kcalPer100g: 66,
        proteinPer100g: 4,
        fatPer100g: 4,
        carbPer100g: 5,
        portionPresets: [{ label: '1 ч.л.', grams: 5 }],
        nutritionTags: ['healthy'],
        notes: 'Зависит от бренда.'
      },
      {
        id: 'prod-tomato-paste',
        name: 'Томатная паста (approx)',
        kcalPer100g: 82,
        proteinPer100g: 4.3,
        fatPer100g: 0.5,
        carbPer100g: 19,
        hydrationContribution: true,
        portionPresets: [{ label: '1 ст.л.', grams: 20 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-lemon-juice',
        name: 'Лимонный сок (approx)',
        kcalPer100g: 22,
        carbPer100g: 6.9,
        hydrationContribution: true,
        portionPresets: [{ label: '30 мл', grams: 30 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-cocoa-powder',
        name: 'Какао-порошок без сахара (approx)',
        kcalPer100g: 228,
        proteinPer100g: 20,
        fatPer100g: 14,
        carbPer100g: 58,
        portionPresets: [{ label: '1 ст.л.', grams: 8 }],
        nutritionTags: ['healthy'],
        notes: 'Учитывать при добавлении в каши/десерты.'
      },
      {
        id: 'prod-greek-yogurt-0',
        name: 'Греческий йогурт 0% (approx)',
        kcalPer100g: 59,
        proteinPer100g: 10,
        fatPer100g: 0.2,
        carbPer100g: 3.5,
        hydrationContribution: true,
        portionPresets: [{ label: '200 г', grams: 200 }],
        nutritionTags: ['healthy', 'snack']
      },
      {
        id: 'prod-tuna-fresh',
        name: 'Тунец (филе, сырое, approx)',
        kcalPer100g: 132,
        proteinPer100g: 29,
        fatPer100g: 1,
        carbPer100g: 0,
        portionPresets: [{ label: '1 порция', grams: 170 }],
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-oat-milk-unsweet',
        name: 'Овсяное молоко без сахара (approx)',
        kcalPer100g: 40,
        proteinPer100g: 1,
        fatPer100g: 1.5,
        carbPer100g: 6,
        hydrationContribution: true,
        portionPresets: [{ label: '250 мл', grams: 250 }],
        nutritionTags: ['healthy'],
        notes: 'Зависит от бренда.'
      },
      {
        id: 'prod-berries-mix-frozen',
        name: 'Ягодная смесь (замороженная, approx)',
        kcalPer100g: 45,
        hydrationContribution: true,
        portionPresets: [{ label: '200 г', grams: 200 }],
        nutritionTags: ['healthy', 'snack']
      },
      {
        id: 'prod-bell-pepper-red',
        name: 'Перец болгарский красный (approx)',
        kcalPer100g: 31,
        hydrationContribution: true,
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-cucumber-pickled',
        name: 'Огурцы маринованные (approx)',
        kcalPer100g: 12,
        hydrationContribution: true,
        nutritionTags: ['healthy'],
        notes: 'Соль учитывать по самочувствию.'
      },
      {
        id: 'prod-sauerkraut',
        name: 'Квашеная капуста (approx)',
        kcalPer100g: 19,
        hydrationContribution: true,
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-seaweed',
        name: 'Морская капуста (ламинария, approx)',
        kcalPer100g: 43,
        hydrationContribution: true,
        nutritionTags: ['healthy']
      },
      {
        id: 'prod-olive-oil-spray',
        name: 'Оливковое масло (спрей, approx)',
        kcalPer100g: 884,
        fatPer100g: 100,
        portionPresets: [{ label: '1 сек. распыления', grams: 1 }],
        nutritionTags: ['healthy'],
        notes: 'Усреднённо: 1 г на 1 сек.'
      },

      // --- Cheat / «вредные» продукты (снэки, сладкое, фастфуд, полуфабрикаты, соусы) ---
      {
        id: 'prod-sugar-white',
        name: 'Сахар белый',
        kcalPer100g: 400,
        proteinPer100g: 0,
        fatPer100g: 0,
        carbPer100g: 100,
        portionPresets: [
          { label: '1 ч.л.', grams: 5 },
          { label: '1 ст.л.', grams: 12 }
        ],
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-sugar-brown',
        name: 'Сахар коричневый',
        kcalPer100g: 380,
        proteinPer100g: 0,
        fatPer100g: 0,
        carbPer100g: 98,
        portionPresets: [
          { label: '1 ч.л.', grams: 5 },
          { label: '1 ст.л.', grams: 12 }
        ],
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-sugar-powder',
        name: 'Сахарная пудра',
        kcalPer100g: 400,
        proteinPer100g: 0,
        fatPer100g: 0,
        carbPer100g: 100,
        portionPresets: [
          { label: '1 ч.л.', grams: 4 },
          { label: '1 ст.л.', grams: 10 }
        ],
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-honey',
        name: 'Мёд',
        kcalPer100g: 304,
        proteinPer100g: 0.3,
        fatPer100g: 0,
        carbPer100g: 82,
        portionPresets: [
          { label: '1 ч.л.', grams: 7 },
          { label: '1 ст.л.', grams: 21 }
        ],
        nutritionTags: ['cheat'],
        notes: 'По сути быстрые углеводы; удобно учитывать в рецептах.'
      },
      {
        id: 'prod-maple-syrup',
        name: 'Кленовый сироп',
        kcalPer100g: 260,
        proteinPer100g: 0,
        fatPer100g: 0,
        carbPer100g: 67,
        portionPresets: [{ label: '1 ст.л.', grams: 20 }],
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-jam',
        name: 'Джем (средний, approx)',
        kcalPer100g: 250,
        proteinPer100g: 0.5,
        fatPer100g: 0.2,
        carbPer100g: 65,
        portionPresets: [{ label: '1 ст.л.', grams: 20 }],
        nutritionTags: ['cheat', 'snack']
      },
      {
        id: 'prod-chocolate-spread',
        name: 'Шоколадная паста (тип Nutella, approx)',
        kcalPer100g: 539,
        proteinPer100g: 6,
        fatPer100g: 31,
        carbPer100g: 57,
        portionPresets: [{ label: '1 ст.л.', grams: 20 }],
        nutritionTags: ['cheat', 'snack']
      },
      {
        id: 'prod-caramel-sauce',
        name: 'Карамельный соус (approx)',
        kcalPer100g: 320,
        proteinPer100g: 1,
        fatPer100g: 3,
        carbPer100g: 75,
        portionPresets: [{ label: '1 ст.л.', grams: 20 }],
        nutritionTags: ['cheat']
      },

      // Мука / тесто / выпечка (как ингредиенты для рецептов)
      {
        id: 'prod-flour-wheat-white',
        name: 'Мука пшеничная (в/с, approx)',
        kcalPer100g: 364,
        proteinPer100g: 10,
        fatPer100g: 1,
        carbPer100g: 76,
        portionPresets: [
          { label: '50 г', grams: 50 },
          { label: '100 г', grams: 100 }
        ],
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-starch-corn',
        name: 'Кукурузный крахмал',
        kcalPer100g: 381,
        proteinPer100g: 0.3,
        fatPer100g: 0.1,
        carbPer100g: 91,
        portionPresets: [{ label: '1 ст.л.', grams: 10 }],
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-breadcrumbs',
        name: 'Панировочные сухари (approx)',
        kcalPer100g: 351,
        proteinPer100g: 13,
        fatPer100g: 5,
        carbPer100g: 70,
        portionPresets: [{ label: '30 г', grams: 30 }],
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-puff-pastry',
        name: 'Тесто слоёное (approx)',
        kcalPer100g: 558,
        proteinPer100g: 7,
        fatPer100g: 38,
        carbPer100g: 45,
        portionPresets: [{ label: '1 пласт', grams: 200 }],
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-yeast-dough',
        name: 'Тесто дрожжевое (approx)',
        kcalPer100g: 250,
        proteinPer100g: 7,
        fatPer100g: 5,
        carbPer100g: 45,
        portionPresets: [{ label: '200 г', grams: 200 }],
        nutritionTags: ['cheat']
      },

      // Масло/молочка повышенной жирности
      {
        id: 'prod-butter',
        name: 'Сливочное масло 82% (approx)',
        kcalPer100g: 717,
        proteinPer100g: 0.8,
        fatPer100g: 81,
        carbPer100g: 0.6,
        portionPresets: [
          { label: '10 г', grams: 10 },
          { label: '1 ст.л.', grams: 14 }
        ],
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-margarine',
        name: 'Маргарин (approx)',
        kcalPer100g: 720,
        proteinPer100g: 0.5,
        fatPer100g: 80,
        carbPer100g: 1,
        portionPresets: [
          { label: '10 г', grams: 10 },
          { label: '1 ст.л.', grams: 14 }
        ],
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-cream-33',
        name: 'Сливки 33% (approx)',
        kcalPer100g: 322,
        proteinPer100g: 2,
        fatPer100g: 33,
        carbPer100g: 3,
        portionPresets: [{ label: '50 мл', grams: 50 }],
        hydrationContribution: true,
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-sour-cream-20',
        name: 'Сметана 20% (approx)',
        kcalPer100g: 206,
        proteinPer100g: 2.5,
        fatPer100g: 20,
        carbPer100g: 3.2,
        portionPresets: [{ label: '1 ст.л.', grams: 25 }],
        hydrationContribution: true,
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-cream-cheese',
        name: 'Сыр сливочный (cream cheese, approx)',
        kcalPer100g: 300,
        proteinPer100g: 6,
        fatPer100g: 28,
        carbPer100g: 4,
        portionPresets: [{ label: '30 г', grams: 30 }],
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-processed-cheese',
        name: 'Сыр плавленый (approx)',
        kcalPer100g: 270,
        proteinPer100g: 12,
        fatPer100g: 22,
        carbPer100g: 3,
        portionPresets: [{ label: '1 ломтик', grams: 20 }],
        pieceGrams: 20,
        pieceLabel: 'ломтик',
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-condensed-milk',
        name: 'Молоко сгущённое (approx)',
        kcalPer100g: 321,
        proteinPer100g: 8,
        fatPer100g: 9,
        carbPer100g: 56,
        portionPresets: [{ label: '1 ст.л.', grams: 20 }],
        nutritionTags: ['cheat', 'snack']
      },
      {
        id: 'prod-ice-cream-vanilla',
        name: 'Мороженое ванильное (approx)',
        kcalPer100g: 207,
        proteinPer100g: 3.5,
        fatPer100g: 11,
        carbPer100g: 24,
        portionPresets: [{ label: '1 шар', grams: 70 }],
        pieceGrams: 70,
        pieceLabel: 'шар',
        nutritionTags: ['cheat', 'snack']
      },

      // Хлеб/выпечка/десерты
      {
        id: 'prod-bread-white',
        name: 'Хлеб белый (approx)',
        kcalPer100g: 265,
        proteinPer100g: 9,
        fatPer100g: 3.2,
        carbPer100g: 49,
        portionPresets: [{ label: '1 ломтик', grams: 30 }],
        pieceGrams: 30,
        pieceLabel: 'ломтик',
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-baguette',
        name: 'Багет (approx)',
        kcalPer100g: 270,
        proteinPer100g: 9,
        fatPer100g: 1.5,
        carbPer100g: 56,
        portionPresets: [{ label: '1 ломтик', grams: 35 }],
        pieceGrams: 35,
        pieceLabel: 'ломтик',
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-bread-toast',
        name: 'Хлеб тостовый (approx)',
        kcalPer100g: 255,
        proteinPer100g: 8,
        fatPer100g: 3.5,
        carbPer100g: 48,
        portionPresets: [{ label: '1 тост', grams: 30 }],
        pieceGrams: 30,
        pieceLabel: 'тост',
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-croissant',
        name: 'Круассан (approx)',
        kcalPer100g: 406,
        proteinPer100g: 8,
        fatPer100g: 21,
        carbPer100g: 45,
        portionPresets: [{ label: '1 шт.', grams: 60 }],
        pieceGrams: 60,
        pieceLabel: 'шт.',
        nutritionTags: ['cheat', 'snack']
      },
      {
        id: 'prod-donut',
        name: 'Пончик (approx)',
        kcalPer100g: 452,
        proteinPer100g: 5,
        fatPer100g: 25,
        carbPer100g: 50,
        portionPresets: [{ label: '1 шт.', grams: 70 }],
        pieceGrams: 70,
        pieceLabel: 'шт.',
        nutritionTags: ['cheat', 'snack']
      },
      {
        id: 'prod-muffin',
        name: 'Маффин (approx)',
        kcalPer100g: 377,
        proteinPer100g: 6,
        fatPer100g: 17,
        carbPer100g: 51,
        portionPresets: [{ label: '1 шт.', grams: 100 }],
        pieceGrams: 100,
        pieceLabel: 'шт.',
        nutritionTags: ['cheat', 'snack']
      },
      {
        id: 'prod-cake-sponge',
        name: 'Бисквит (approx)',
        kcalPer100g: 320,
        proteinPer100g: 6,
        fatPer100g: 9,
        carbPer100g: 54,
        portionPresets: [{ label: '1 кусок', grams: 80 }],
        pieceGrams: 80,
        pieceLabel: 'кусок',
        nutritionTags: ['cheat', 'snack']
      },
      {
        id: 'prod-cookies-butter',
        name: 'Печенье песочное (approx)',
        kcalPer100g: 502,
        proteinPer100g: 6,
        fatPer100g: 24,
        carbPer100g: 66,
        portionPresets: [{ label: '3 шт.', grams: 45 }],
        pieceGrams: 15,
        pieceLabel: 'шт.',
        nutritionTags: ['cheat', 'snack']
      },
      {
        id: 'prod-cookies-choco',
        name: 'Печенье с шоколадом (approx)',
        kcalPer100g: 488,
        proteinPer100g: 5,
        fatPer100g: 22,
        carbPer100g: 68,
        portionPresets: [{ label: '2 шт.', grams: 40 }],
        pieceGrams: 20,
        pieceLabel: 'шт.',
        nutritionTags: ['cheat', 'snack']
      },
      {
        id: 'prod-waffles',
        name: 'Вафли (approx)',
        kcalPer100g: 520,
        proteinPer100g: 6,
        fatPer100g: 30,
        carbPer100g: 55,
        portionPresets: [{ label: '2 шт.', grams: 40 }],
        pieceGrams: 20,
        pieceLabel: 'шт.',
        nutritionTags: ['cheat', 'snack']
      },

      // Шоколад/конфеты
      {
        id: 'prod-chocolate-milk',
        name: 'Шоколад молочный (approx)',
        kcalPer100g: 535,
        proteinPer100g: 7,
        fatPer100g: 30,
        carbPer100g: 59,
        portionPresets: [
          { label: '1 долька', grams: 10 },
          { label: '1 плитка', grams: 100 }
        ],
        pieceGrams: 10,
        pieceLabel: 'долька',
        nutritionTags: ['cheat', 'snack']
      },
      {
        id: 'prod-chocolate-dark-70',
        name: 'Шоколад тёмный 70% (approx)',
        kcalPer100g: 579,
        proteinPer100g: 8,
        fatPer100g: 42,
        carbPer100g: 46,
        portionPresets: [{ label: '1 долька', grams: 10 }],
        pieceGrams: 10,
        pieceLabel: 'долька',
        nutritionTags: ['cheat', 'snack']
      },
      {
        id: 'prod-chocolate-bar',
        name: 'Шоколадный батончик (approx)',
        kcalPer100g: 500,
        proteinPer100g: 6,
        fatPer100g: 25,
        carbPer100g: 60,
        portionPresets: [{ label: '1 батончик', grams: 50 }],
        pieceGrams: 50,
        pieceLabel: 'батончик',
        nutritionTags: ['cheat', 'snack']
      },
      {
        id: 'prod-candy-hard',
        name: 'Конфеты леденцы (approx)',
        kcalPer100g: 390,
        proteinPer100g: 0,
        fatPer100g: 0,
        carbPer100g: 97,
        portionPresets: [{ label: '3 шт.', grams: 18 }],
        pieceGrams: 6,
        pieceLabel: 'шт.',
        nutritionTags: ['cheat', 'snack']
      },
      {
        id: 'prod-gummy-bears',
        name: 'Жевательный мармелад (approx)',
        kcalPer100g: 340,
        proteinPer100g: 6,
        fatPer100g: 0.2,
        carbPer100g: 80,
        portionPresets: [{ label: '30 г', grams: 30 }],
        nutritionTags: ['cheat', 'snack']
      },
      {
        id: 'prod-marshmallow',
        name: 'Маршмеллоу (approx)',
        kcalPer100g: 318,
        proteinPer100g: 1.8,
        fatPer100g: 0.2,
        carbPer100g: 80,
        portionPresets: [{ label: '25 г', grams: 25 }],
        nutritionTags: ['cheat', 'snack']
      },

      // Чипсы/солёные снеки
      {
        id: 'prod-chips-potato',
        name: 'Чипсы картофельные (approx)',
        kcalPer100g: 536,
        proteinPer100g: 7,
        fatPer100g: 35,
        carbPer100g: 50,
        portionPresets: [{ label: 'порция', grams: 40 }],
        nutritionTags: ['cheat', 'snack']
      },
      {
        id: 'prod-nachos',
        name: 'Начос (чипсы кукурузные, approx)',
        kcalPer100g: 480,
        proteinPer100g: 7,
        fatPer100g: 24,
        carbPer100g: 60,
        portionPresets: [{ label: 'порция', grams: 40 }],
        nutritionTags: ['cheat', 'snack']
      },
      {
        id: 'prod-crackers-salty',
        name: 'Крекеры солёные (approx)',
        kcalPer100g: 430,
        proteinPer100g: 10,
        fatPer100g: 10,
        carbPer100g: 72,
        portionPresets: [{ label: '30 г', grams: 30 }],
        nutritionTags: ['cheat', 'snack']
      },
      {
        id: 'prod-pretzels',
        name: 'Претцели (солёные, approx)',
        kcalPer100g: 380,
        proteinPer100g: 10,
        fatPer100g: 3,
        carbPer100g: 78,
        portionPresets: [{ label: '40 г', grams: 40 }],
        nutritionTags: ['cheat', 'snack']
      },
      {
        id: 'prod-popcorn-butter',
        name: 'Попкорн с маслом (approx)',
        kcalPer100g: 500,
        proteinPer100g: 7,
        fatPer100g: 28,
        carbPer100g: 55,
        portionPresets: [{ label: 'порция', grams: 30 }],
        nutritionTags: ['cheat', 'snack']
      },
      {
        id: 'prod-popcorn-sweet',
        name: 'Попкорн сладкий (approx)',
        kcalPer100g: 420,
        proteinPer100g: 5,
        fatPer100g: 12,
        carbPer100g: 75,
        portionPresets: [{ label: 'порция', grams: 30 }],
        nutritionTags: ['cheat', 'snack']
      },
      {
        id: 'prod-peanuts-salted',
        name: 'Арахис солёный (approx)',
        kcalPer100g: 620,
        proteinPer100g: 26,
        fatPer100g: 52,
        carbPer100g: 14,
        portionPresets: [{ label: '30 г', grams: 30 }],
        nutritionTags: ['cheat', 'snack'],
        notes: 'Соль/калорийность учитывать при перекусах.'
      },

      // Соусы/заправки (частые «дыры» в рецептах)
      {
        id: 'prod-mayonnaise',
        name: 'Майонез (approx)',
        kcalPer100g: 680,
        proteinPer100g: 1,
        fatPer100g: 75,
        carbPer100g: 2,
        portionPresets: [{ label: '1 ст.л.', grams: 14 }],
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-ketchup',
        name: 'Кетчуп (approx)',
        kcalPer100g: 100,
        proteinPer100g: 1,
        fatPer100g: 0.2,
        carbPer100g: 25,
        portionPresets: [{ label: '1 ст.л.', grams: 15 }],
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-bbq-sauce',
        name: 'Соус BBQ (approx)',
        kcalPer100g: 150,
        proteinPer100g: 1,
        fatPer100g: 0.5,
        carbPer100g: 35,
        portionPresets: [{ label: '1 ст.л.', grams: 20 }],
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-teriyaki-sauce',
        name: 'Соус терияки (approx)',
        kcalPer100g: 90,
        proteinPer100g: 2,
        fatPer100g: 0.2,
        carbPer100g: 15,
        portionPresets: [{ label: '1 ст.л.', grams: 20 }],
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-sweet-chili-sauce',
        name: 'Соус сладкий чили (approx)',
        kcalPer100g: 200,
        proteinPer100g: 1,
        fatPer100g: 0.2,
        carbPer100g: 50,
        portionPresets: [{ label: '1 ст.л.', grams: 20 }],
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-caesar-dressing',
        name: 'Заправка «Цезарь» (approx)',
        kcalPer100g: 520,
        proteinPer100g: 2,
        fatPer100g: 55,
        carbPer100g: 5,
        portionPresets: [{ label: '2 ст.л.', grams: 30 }],
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-ranch-dressing',
        name: 'Заправка Ranch (approx)',
        kcalPer100g: 450,
        proteinPer100g: 2,
        fatPer100g: 45,
        carbPer100g: 6,
        portionPresets: [{ label: '2 ст.л.', grams: 30 }],
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-cheese-sauce',
        name: 'Сырный соус (approx)',
        kcalPer100g: 250,
        proteinPer100g: 6,
        fatPer100g: 20,
        carbPer100g: 8,
        portionPresets: [{ label: '2 ст.л.', grams: 30 }],
        nutritionTags: ['cheat']
      },

      // Колбасы/переработанное мясо
      {
        id: 'prod-bacon',
        name: 'Бекон (approx)',
        kcalPer100g: 541,
        proteinPer100g: 37,
        fatPer100g: 42,
        carbPer100g: 1.4,
        portionPresets: [{ label: '2 ломтика', grams: 30 }],
        pieceGrams: 15,
        pieceLabel: 'ломтик',
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-salami',
        name: 'Салями (approx)',
        kcalPer100g: 407,
        proteinPer100g: 22,
        fatPer100g: 34,
        carbPer100g: 2,
        portionPresets: [{ label: '3 ломтика', grams: 30 }],
        pieceGrams: 10,
        pieceLabel: 'ломтик',
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-sausage-smoked',
        name: 'Колбаса копчёная (approx)',
        kcalPer100g: 360,
        proteinPer100g: 15,
        fatPer100g: 33,
        carbPer100g: 2,
        portionPresets: [{ label: '50 г', grams: 50 }],
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-sausage-hotdog',
        name: 'Сосиски (hot dog, approx)',
        kcalPer100g: 290,
        proteinPer100g: 10,
        fatPer100g: 26,
        carbPer100g: 2,
        portionPresets: [{ label: '2 шт.', grams: 100 }],
        pieceGrams: 50,
        pieceLabel: 'шт.',
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-ham',
        name: 'Ветчина (approx)',
        kcalPer100g: 145,
        proteinPer100g: 21,
        fatPer100g: 6,
        carbPer100g: 1,
        portionPresets: [{ label: '3 ломтика', grams: 45 }],
        pieceGrams: 15,
        pieceLabel: 'ломтик',
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-pate',
        name: 'Паштет (approx)',
        kcalPer100g: 320,
        proteinPer100g: 12,
        fatPer100g: 28,
        carbPer100g: 3,
        portionPresets: [{ label: '30 г', grams: 30 }],
        nutritionTags: ['cheat']
      },

      // Фастфуд/готовое (как продукты для быстрого логинга)
      {
        id: 'prod-french-fries',
        name: 'Картофель фри (approx)',
        kcalPer100g: 312,
        proteinPer100g: 3.4,
        fatPer100g: 15,
        carbPer100g: 41,
        portionPresets: [{ label: 'порция', grams: 150 }],
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-pizza-pepperoni',
        name: 'Пицца «Пепперони» (1 кусок, approx)',
        kcalPer100g: 290,
        proteinPer100g: 12,
        fatPer100g: 12,
        carbPer100g: 32,
        portionPresets: [{ label: '1 кусок', grams: 120 }],
        pieceGrams: 120,
        pieceLabel: 'кусок',
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-pizza-margherita',
        name: 'Пицца «Маргарита» (1 кусок, approx)',
        kcalPer100g: 250,
        proteinPer100g: 11,
        fatPer100g: 9,
        carbPer100g: 30,
        portionPresets: [{ label: '1 кусок', grams: 120 }],
        pieceGrams: 120,
        pieceLabel: 'кусок',
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-cheeseburger',
        name: 'Чизбургер (approx)',
        kcalPer100g: 260,
        proteinPer100g: 13,
        fatPer100g: 14,
        carbPer100g: 21,
        portionPresets: [{ label: '1 шт.', grams: 170 }],
        pieceGrams: 170,
        pieceLabel: 'шт.',
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-chicken-nuggets',
        name: 'Куриные наггетсы (approx)',
        kcalPer100g: 290,
        proteinPer100g: 15,
        fatPer100g: 19,
        carbPer100g: 16,
        portionPresets: [{ label: '6 шт.', grams: 120 }],
        pieceGrams: 20,
        pieceLabel: 'шт.',
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-fried-chicken',
        name: 'Курица жареная в панировке (approx)',
        kcalPer100g: 260,
        proteinPer100g: 18,
        fatPer100g: 15,
        carbPer100g: 12,
        portionPresets: [{ label: 'порция', grams: 180 }],
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-shawarma',
        name: 'Шаурма (approx)',
        kcalPer100g: 220,
        proteinPer100g: 12,
        fatPer100g: 12,
        carbPer100g: 17,
        portionPresets: [{ label: '1 шт.', grams: 350 }],
        pieceGrams: 350,
        pieceLabel: 'шт.',
        nutritionTags: ['cheat']
      },

      // Полуфабрикаты/быстрые блюда
      {
        id: 'prod-pelmeni',
        name: 'Пельмени (варёные, approx)',
        kcalPer100g: 250,
        proteinPer100g: 10,
        fatPer100g: 12,
        carbPer100g: 26,
        portionPresets: [{ label: 'порция', grams: 250 }],
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-dumplings-vareniki',
        name: 'Вареники (с картофелем, approx)',
        kcalPer100g: 190,
        proteinPer100g: 5,
        fatPer100g: 3,
        carbPer100g: 36,
        portionPresets: [{ label: 'порция', grams: 250 }],
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-instant-noodles',
        name: 'Лапша быстрого приготовления (сухая, approx)',
        kcalPer100g: 450,
        proteinPer100g: 9,
        fatPer100g: 18,
        carbPer100g: 65,
        portionPresets: [{ label: '1 упаковка', grams: 85 }],
        pieceGrams: 85,
        pieceLabel: 'упак.',
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-frozen-pancakes',
        name: 'Блины (готовые, approx)',
        kcalPer100g: 230,
        proteinPer100g: 6,
        fatPer100g: 10,
        carbPer100g: 28,
        portionPresets: [{ label: '2 шт.', grams: 120 }],
        pieceGrams: 60,
        pieceLabel: 'шт.',
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-frozen-pizza',
        name: 'Пицца замороженная (approx)',
        kcalPer100g: 270,
        proteinPer100g: 11,
        fatPer100g: 10,
        carbPer100g: 33,
        portionPresets: [{ label: '1/2 пиццы', grams: 200 }],
        nutritionTags: ['cheat']
      },
      {
        id: 'prod-lasagna',
        name: 'Лазанья (готовая, approx)',
        kcalPer100g: 150,
        proteinPer100g: 7,
        fatPer100g: 7,
        carbPer100g: 14,
        portionPresets: [{ label: 'порция', grams: 300 }],
        nutritionTags: ['cheat']
      },
      // --- Дополнение cheat-базы: десерты, соусы, сыры, полуфабрикаты ---
      {
        id: 'prod-white-chocolate',
        name: 'Шоколад белый',
        kcalPer100g: 540,
        proteinPer100g: 6,
        fatPer100g: 32,
        carbPer100g: 58,
        portionPresets: [
            {label: '2 дольки', grams: 20},
            {label: '1 плитка', grams: 90}
          ],
        nutritionTags: ['cheat', 'snack'],
      },
      {
        id: 'prod-chocolate-chips',
        name: 'Шоколадная крошка/чипсы (для выпечки, approx)',
        kcalPer100g: 500,
        proteinPer100g: 5,
        fatPer100g: 28,
        carbPer100g: 60,
        portionPresets: [
            {label: '1 ст.л.', grams: 15},
            {label: '30 г', grams: 30}
          ],
        nutritionTags: ['cheat'],
      },
      {
        id: 'prod-caramel-candy',
        name: 'Ирис/карамель (конфеты, approx)',
        kcalPer100g: 380,
        proteinPer100g: 2,
        fatPer100g: 7,
        carbPer100g: 80,
        portionPresets: [
            {label: '2 шт.', grams: 12},
            {label: 'горсть', grams: 30}
          ],
        pieceGrams: 6,
        pieceLabel: 'шт.',
        nutritionTags: ['cheat', 'snack'],
      },
      {
        id: 'prod-toffee-sauce',
        name: 'Соус ирис/тоффи (dessert topping, approx)',
        kcalPer100g: 320,
        proteinPer100g: 1,
        fatPer100g: 5,
        carbPer100g: 70,
        portionPresets: [
            {label: '1 ст.л.', grams: 20}
          ],
        nutritionTags: ['cheat'],
      },
      {
        id: 'prod-whipped-cream-spray',
        name: 'Взбитые сливки (аэрозоль, approx)',
        kcalPer100g: 290,
        proteinPer100g: 2,
        fatPer100g: 23,
        carbPer100g: 16,
        portionPresets: [
            {label: 'порция', grams: 30}
          ],
        nutritionTags: ['cheat'],
      },
      {
        id: 'prod-cinnamon-roll',
        name: 'Булочка с корицей (cinnamon roll, approx)',
        kcalPer100g: 330,
        proteinPer100g: 6,
        fatPer100g: 12,
        carbPer100g: 50,
        portionPresets: [
            {label: '1 шт.', grams: 110}
          ],
        pieceGrams: 110,
        pieceLabel: 'шт.',
        nutritionTags: ['cheat', 'snack'],
      },
      {
        id: 'prod-brownie',
        name: 'Брауни (approx)',
        kcalPer100g: 450,
        proteinPer100g: 5,
        fatPer100g: 23,
        carbPer100g: 55,
        portionPresets: [
            {label: 'кусок', grams: 60}
          ],
        nutritionTags: ['cheat', 'snack'],
      },
      {
        id: 'prod-cheesecake',
        name: 'Чизкейк (approx)',
        kcalPer100g: 320,
        proteinPer100g: 6,
        fatPer100g: 22,
        carbPer100g: 26,
        portionPresets: [
            {label: 'кусок', grams: 120}
          ],
        nutritionTags: ['cheat', 'snack'],
      },
      {
        id: 'prod-cupcake',
        name: 'Капкейк (approx)',
        kcalPer100g: 390,
        proteinPer100g: 5,
        fatPer100g: 18,
        carbPer100g: 52,
        portionPresets: [
            {label: '1 шт.', grams: 80}
          ],
        pieceGrams: 80,
        pieceLabel: 'шт.',
        nutritionTags: ['cheat', 'snack'],
      },
      {
        id: 'prod-eclair',
        name: 'Эклер (approx)',
        kcalPer100g: 300,
        proteinPer100g: 6,
        fatPer100g: 18,
        carbPer100g: 28,
        portionPresets: [
            {label: '1 шт.', grams: 70}
          ],
        pieceGrams: 70,
        pieceLabel: 'шт.',
        nutritionTags: ['cheat', 'snack'],
      },
      {
        id: 'prod-chocolate-cake',
        name: 'Торт шоколадный (approx)',
        kcalPer100g: 350,
        proteinPer100g: 5,
        fatPer100g: 15,
        carbPer100g: 50,
        portionPresets: [
            {label: 'кусок', grams: 120}
          ],
        nutritionTags: ['cheat', 'snack'],
      },
      {
        id: 'prod-cornflakes-sweet',
        name: 'Хлопья кукурузные сладкие (approx)',
        kcalPer100g: 380,
        proteinPer100g: 7,
        fatPer100g: 2,
        carbPer100g: 84,
        portionPresets: [
            {label: '1 миска', grams: 45}
          ],
        nutritionTags: ['cheat', 'snack'],
      },
      {
        id: 'prod-sweet-cereal',
        name: 'Сухой завтрак сладкий (шарики/кольца, approx)',
        kcalPer100g: 390,
        proteinPer100g: 7,
        fatPer100g: 4,
        carbPer100g: 82,
        portionPresets: [
            {label: '1 миска', grams: 50}
          ],
        nutritionTags: ['cheat', 'snack'],
      },
      {
        id: 'prod-granola-sweet',
        name: 'Гранола сладкая (с мёдом/сиропом, approx)',
        kcalPer100g: 450,
        proteinPer100g: 9,
        fatPer100g: 18,
        carbPer100g: 64,
        portionPresets: [
            {label: '50 г', grams: 50}
          ],
        nutritionTags: ['cheat', 'snack'],
      },
      {
        id: 'prod-cereal-bar',
        name: 'Батончик мюсли/злаковый (с сахаром, approx)',
        kcalPer100g: 410,
        proteinPer100g: 6,
        fatPer100g: 12,
        carbPer100g: 70,
        portionPresets: [
            {label: '1 батончик', grams: 35}
          ],
        pieceGrams: 35,
        pieceLabel: 'шт.',
        nutritionTags: ['cheat', 'snack'],
      },
      {
        id: 'prod-jam-strawberry',
        name: 'Варенье клубничное (approx)',
        kcalPer100g: 250,
        proteinPer100g: 0.5,
        fatPer100g: 0.2,
        carbPer100g: 65,
        portionPresets: [
            {label: '1 ст.л.', grams: 20}
          ],
        nutritionTags: ['cheat'],
      },
      {
        id: 'prod-jam-apricot',
        name: 'Джем абрикосовый (approx)',
        kcalPer100g: 240,
        proteinPer100g: 0.4,
        fatPer100g: 0.2,
        carbPer100g: 62,
        portionPresets: [
            {label: '1 ст.л.', grams: 20}
          ],
        nutritionTags: ['cheat'],
      },
      {
        id: 'prod-peanut-butter-sweet',
        name: 'Арахисовая паста сладкая (с сахаром, approx)',
        kcalPer100g: 600,
        proteinPer100g: 24,
        fatPer100g: 46,
        carbPer100g: 22,
        portionPresets: [
            {label: '1 ст.л.', grams: 16}
          ],
        nutritionTags: ['cheat'],
      },
      {
        id: 'prod-aioli',
        name: 'Айоли (соус, approx)',
        kcalPer100g: 650,
        proteinPer100g: 1,
        fatPer100g: 72,
        carbPer100g: 2,
        portionPresets: [
            {label: '1 ст.л.', grams: 14}
          ],
        nutritionTags: ['cheat'],
      },
      {
        id: 'prod-tartar-sauce',
        name: 'Соус тартар (approx)',
        kcalPer100g: 450,
        proteinPer100g: 1,
        fatPer100g: 45,
        carbPer100g: 10,
        portionPresets: [
            {label: '1 ст.л.', grams: 20}
          ],
        nutritionTags: ['cheat'],
      },
      {
        id: 'prod-thousand-island',
        name: 'Соус 1000 островов (approx)',
        kcalPer100g: 380,
        proteinPer100g: 1,
        fatPer100g: 35,
        carbPer100g: 15,
        portionPresets: [
            {label: '1 ст.л.', grams: 20}
          ],
        nutritionTags: ['cheat'],
      },
      {
        id: 'prod-cheddar',
        name: 'Сыр Чеддер (approx)',
        kcalPer100g: 403,
        proteinPer100g: 25,
        fatPer100g: 33,
        carbPer100g: 1.3,
        portionPresets: [
            {label: '30 г', grams: 30}
          ],
        nutritionTags: ['cheat'],
      },
      {
        id: 'prod-mozzarella',
        name: 'Сыр Моцарелла (approx)',
        kcalPer100g: 280,
        proteinPer100g: 18,
        fatPer100g: 22,
        carbPer100g: 2,
        portionPresets: [
            {label: '50 г', grams: 50}
          ],
        nutritionTags: ['cheat'],
      },
      {
        id: 'prod-parmesan',
        name: 'Сыр Пармезан (approx)',
        kcalPer100g: 431,
        proteinPer100g: 38,
        fatPer100g: 29,
        carbPer100g: 4,
        portionPresets: [
            {label: '20 г', grams: 20}
          ],
        nutritionTags: ['cheat'],
      },
      {
        id: 'prod-pepperoni',
        name: 'Пепперони (колбаса, approx)',
        kcalPer100g: 494,
        proteinPer100g: 20,
        fatPer100g: 44,
        carbPer100g: 2,
        portionPresets: [
            {label: '30 г', grams: 30}
          ],
        nutritionTags: ['cheat'],
      },
      {
        id: 'prod-chorizo',
        name: 'Чоризо (колбаса, approx)',
        kcalPer100g: 455,
        proteinPer100g: 24,
        fatPer100g: 38,
        carbPer100g: 2,
        portionPresets: [
            {label: '30 г', grams: 30}
          ],
        nutritionTags: ['cheat'],
      },
      {
        id: 'prod-bologna',
        name: 'Колбаса варёная (болонья/докторская, approx)',
        kcalPer100g: 260,
        proteinPer100g: 12,
        fatPer100g: 22,
        carbPer100g: 2,
        portionPresets: [
            {label: '2 ломтика', grams: 40}
          ],
        nutritionTags: ['cheat'],
      },
      {
        id: 'prod-onion-rings',
        name: 'Луковые кольца (фритюр, approx)',
        kcalPer100g: 350,
        proteinPer100g: 4,
        fatPer100g: 20,
        carbPer100g: 40,
        portionPresets: [
            {label: 'порция', grams: 150}
          ],
        nutritionTags: ['cheat'],
      },
      {
        id: 'prod-mozzarella-sticks',
        name: 'Сырные палочки (фритюр, approx)',
        kcalPer100g: 330,
        proteinPer100g: 14,
        fatPer100g: 22,
        carbPer100g: 20,
        portionPresets: [
            {label: 'порция', grams: 120}
          ],
        nutritionTags: ['cheat'],
      },
      {
        id: 'prod-fish-sticks',
        name: 'Рыбные палочки (панировка, approx)',
        kcalPer100g: 230,
        proteinPer100g: 12,
        fatPer100g: 12,
        carbPer100g: 18,
        portionPresets: [
            {label: '6 шт.', grams: 150}
          ],
        pieceGrams: 25,
        pieceLabel: 'шт.',
        nutritionTags: ['cheat'],
      },
      {
        id: 'prod-instant-mashed-potato',
        name: 'Пюре картофельное быстрого приготовления (сухое, approx)',
        kcalPer100g: 360,
        proteinPer100g: 8,
        fatPer100g: 6,
        carbPer100g: 70,
        portionPresets: [
            {label: '1 порция (сух.)', grams: 50}
          ],
        nutritionTags: ['cheat'],
      },
      {
        id: 'prod-instant-soup',
        name: 'Суп быстрого приготовления (пакет, сухой, approx)',
        kcalPer100g: 350,
        proteinPer100g: 9,
        fatPer100g: 12,
        carbPer100g: 52,
        portionPresets: [
            {label: '1 пакет', grams: 20}
          ],
        pieceGrams: 20,
        pieceLabel: 'пак.',
        nutritionTags: ['cheat'],
      },
      {
        id: 'prod-ravioli-canned',
        name: 'Равиоли консервированные (approx)',
        kcalPer100g: 120,
        proteinPer100g: 5,
        fatPer100g: 3,
        carbPer100g: 18,
        portionPresets: [
            {label: 'банка', grams: 400}
          ],
        nutritionTags: ['cheat'],
      },


    ],
    recipes: [
      {
        id: 'rec-baked-chicken',
        name: 'Запечённая курица',
        servings: 2,
        ingredients: [
          { productRef: 'prod-chicken-thighs', grams: 360 },
          { productRef: 'prod-olive-oil', grams: 10 }
        ],
        steps: ['Смешайте специи.', 'Запекайте 25–30 мин при 200°С.'],
        notes: 'Соль/перец по вкусу.',
        tags: ['ужин'],
        category: 'main',
        nutritionTags: ['healthy']
      },
      {
        id: 'rec-cooked-rice',
        name: 'Рис отварной',
        servings: 3,
        ingredients: [{ productRef: 'prod-rice', grams: 150 }],
        steps: ['Промыть рис.', 'Варить 18–20 мин.'],
        tags: ['гарнир'],
        category: 'side',
        nutritionTags: ['healthy']
      },
      {
        id: 'rec-cooked-buckwheat',
        name: 'Гречка отварная',
        servings: 3,
        ingredients: [{ productRef: 'prod-buckwheat', grams: 180 }],
        steps: ['Промыть гречку.', 'Варить 15–18 мин.'],
        tags: ['гарнир'],
        category: 'side',
        nutritionTags: ['healthy']
      },
      {
        id: 'rec-boiled-potatoes',
        name: 'Картофель отварной',
        servings: 3,
        ingredients: [{ productRef: 'prod-potatoes', grams: 600 }],
        steps: ['Очистить.', 'Варить 20–25 мин.'],
        tags: ['гарнир'],
        category: 'side',
        nutritionTags: ['healthy']
      },
      {
        id: 'rec-salad',
        name: 'Салат огурец + помидор + салат',
        servings: 2,
        ingredients: [
          { productRef: 'prod-cucumber', grams: 200 },
          { productRef: 'prod-tomato', grams: 200 },
          { productRef: 'prod-lettuce', grams: 120 },
          { productRef: 'prod-olive-oil', grams: 10 }
        ],
        steps: ['Нарезать.', 'Смешать.', 'Заправить.'],
        tags: ['салат'],
        category: 'salad',
        nutritionTags: ['healthy']
      },
      {
        id: 'rec-baked-fish',
        name: 'Рыба с лимоном',
        servings: 2,
        ingredients: [
          { productRef: 'prod-fish', grams: 320 },
          { productRef: 'prod-olive-oil', grams: 8 }
        ],
        steps: ['Сбрызнуть лимоном.', 'Запечь 20 мин.'],
        tags: ['ужин'],
        category: 'main',
        nutritionTags: ['healthy']
      },
      {
        id: 'rec-turkey-patties',
        name: 'Котлеты из индейки',
        servings: 3,
        ingredients: [
          { productRef: 'prod-turkey-mince', grams: 450 },
          { productRef: 'prod-onion', grams: 80 }
        ],
        steps: ['Смешать фарш и лук.', 'Сформировать котлеты.', 'Обжарить/запечь.'],
        tags: ['обед'],
        category: 'main',
        nutritionTags: ['healthy']
      },
      {
        id: 'rec-omelet',
        name: 'Омлет 3 яйца + брокколи',
        servings: 1,
        ingredients: [
          { productRef: 'prod-eggs', grams: 150 },
          { productRef: 'prod-broccoli', grams: 100 }
        ],
        steps: ['Взбить яйца.', 'Добавить брокколи.', 'Готовить 6–8 мин.'],
        tags: ['завтрак'],
        category: 'breakfast',
        nutritionTags: ['healthy']
      },
      {
        id: 'rec-oatmeal',
        name: 'Овсянка с яблоком',
        servings: 1,
        ingredients: [
          { productRef: 'prod-oats', grams: 40 },
          { productRef: 'prod-apple', grams: 80 },
          { productRef: 'prod-honey', grams: 8 }
        ],
        steps: ['Сварить овсянку.', 'Добавить яблоко и мёд.'],
        notes: 'Можно добавить корицу.',
        tags: ['завтрак'],
        category: 'breakfast',
        complexity: 'easy',
        nutritionTags: ['healthy']
      },
      {
        id: 'rec-yogurt-dessert',
        name: 'Творожно-йогуртовый десерт',
        servings: 2,
        ingredients: [
          { productRef: 'prod-greek-yogurt', grams: 200 },
          { productRef: 'prod-cottage', grams: 160 },
          { productRef: 'prod-dark-chocolate', grams: 20 }
        ],
        steps: ['Смешать йогурт и творог.', 'Добавить стружку шоколада.'],
        notes: 'Баланс сладкого и белка.',
        tags: ['перекус', 'десерт'],
        category: 'dessert',
        complexity: 'easy',
        nutritionTags: ['snack', 'cheat']
      },
      {
        id: 'rec-smoothie',
        name: 'Смузи банан + кефир',
        servings: 1,
        ingredients: [
          { productRef: 'prod-banana', grams: 120 },
          { productRef: 'prod-kefir', grams: 200 }
        ],
        steps: ['Смешать в блендере 30 секунд.'],
        tags: ['напиток'],
        category: 'drink',
        complexity: 'easy',
        nutritionTags: ['snack'],
        hydrationContribution: true
      }
    ],
    drinks: [
      {
        id: 'drink-water',
        name: 'Вода',
        hydrationFactor: 1,
        kcalPer100ml: 0,
        proteinPer100ml: 0,
        fatPer100ml: 0,
        carbPer100ml: 0,
        portions: [
          { label: 'Стакан 250 мл', ml: 250 },
          { label: 'Бутылка 500 мл', ml: 500 },
          { label: 'Бутылка 750 мл', ml: 750 }
        ]
      },
      {
        id: 'drink-tea',
        name: 'Чай',
        hydrationFactor: 0.9,
        kcalPer100ml: 0,
        proteinPer100ml: 0,
        fatPer100ml: 0,
        carbPer100ml: 0,
        portions: [
          { label: 'Чашка 200 мл', ml: 200 },
          { label: 'Кружка 300 мл', ml: 300 }
        ]
      },
      {
        id: 'drink-coffee',
        name: 'Кофе',
        hydrationFactor: 0.8,
        kcalPer100ml: 0,
        proteinPer100ml: 0,
        fatPer100ml: 0,
        carbPer100ml: 0,
        portions: [
          { label: 'Эспрессо 60 мл', ml: 60 },
          { label: 'Кружка 200 мл', ml: 200 }
        ]
      }
    ],
    rules: [
      {
        id: 'rule-no-delivery',
        name: 'Без доставки в период S0',
        text: 'В период S0 — без доставки, готовим дома.',
        tags: ['питание']
      },
      {
        id: 'rule-delay-cigarette',
        name: 'Отложить первую сигарету',
        text: 'Отложить первую сигарету на 15 минут.',
        tags: ['курение']
      },
      {
        id: 'rule-water-breaths',
        name: 'Перед стрессовой сигаретой: вода + дыхание',
        text: 'Перед стрессовой сигаретой: вода + 10 медленных вдохов.',
        tags: ['курение']
      }
    ],
    movementActivities: [
      {
        id: 'move-run',
        name: 'Бег',
        kind: 'run',
        activityMetrics: { perMinute: 0.05, perKm: 0.35 }
      },
      {
        id: 'move-march',
        name: 'Ходьба на месте',
        kind: 'march',
        activityMetrics: { perMinute: 0.025, perKm: 0.25, perStep: 0.00008 }
      },
      {
        id: 'move-stairs',
        name: 'Ходьба по лестницам',
        kind: 'stairs',
        activityMetrics: { perMinute: 0.04, perFlight: 0.05 }
      }
    ],
    activityDefaults: {
      workoutPerMinute: 0.04,
      movementPerMinute: 0.03,
      step: 0.00008,
      distanceKm: 0.3,
      set: 0.12,
      rep: 0.01,
      kcal: 0.002,
      flight: 0.05,
      exerciseBase: 0.2
    },
    taskTemplates: [
      {
        id: 'tpl-warmup',
        type: 'warmup',
        title: 'Разминка',
        defaultTarget: { minutes: 10 },
        suggestedRefs: [{ kind: 'protocol', refId: 'proto-r10-warmup' }]
      },
      {
        id: 'tpl-movement',
        type: 'movement',
        title: 'Движение',
        defaultTarget: { minutes: 20 }
      },
      {
        id: 'tpl-strength',
        type: 'strength',
        title: 'Силовая',
        defaultTarget: { rounds: 2 },
        suggestedRefs: [{ kind: 'protocol', refId: 'proto-s0-str' }]
      },
      {
        id: 'tpl-nutrition',
        type: 'nutrition',
        title: 'Питание',
        defaultTarget: { meals: 3 },
        suggestedRefs: [{ kind: 'rule', refId: 'rule-no-delivery' }]
      },
      {
        id: 'tpl-smoking',
        type: 'smoking',
        title: 'Курение',
        defaultTarget: { max: 5 },
        suggestedRefs: [
          { kind: 'rule', refId: 'rule-delay-cigarette' },
          { kind: 'rule', refId: 'rule-water-breaths' }
        ]
      },
      {
        id: 'tpl-measurement',
        type: 'measurement',
        title: 'Измерения',
        defaultTarget: { weight: 'kg', waist: 'cm' }
      },
      {
        id: 'tpl-sleep',
        type: 'sleep',
        title: 'Якорь сна',
        defaultTarget: { wake: '07:30' }
      }
    ]
  },
  planner: {
    periods: [
      {
        id: 'period-s0',
        name: 'S0',
        startDate: '2026-01-16',
        endDate: '2026-01-18',
        goals: ['Вернуть базовую активность', 'Стабилизировать сон'],
        notes: 'Черновик периода для старта.'
      }
    ],
    dayPlans: [
      {
        id: 'day-2026-01-16',
        date: '2026-01-16',
        periodId: 'period-s0',
        tasks: [
          {
            id: 'task-16-warmup',
            templateRef: 'tpl-warmup',
            status: 'planned',
            assignedRefs: [{ kind: 'protocol', refId: 'proto-r10-warmup' }],
            target: { minutes: 10 },
            timeOfDay: 'morning',
            notes: 'Разогрев перед силовой.'
          },
          {
            id: 'task-16-nutrition',
            templateRef: 'tpl-nutrition',
            status: 'planned',
            assignedRefs: [{ kind: 'rule', refId: 'rule-no-delivery' }],
            target: { meals: 3 },
            timeOfDay: 'day'
          },
          {
            id: 'task-16-sleep',
            templateRef: 'tpl-sleep',
            status: 'planned',
            target: { wake: '07:30' },
            timeOfDay: 'evening'
          }
        ],
        mealsPlan: {
          breakfast: [
            {
              id: 'plan-16-breakfast-1',
              kind: 'dish',
              refId: 'rec-omelet',
              plannedServings: 1,
              plannedTime: '08:00',
              notes: 'Белок + овощи'
            }
          ],
          lunch: [
            {
              id: 'plan-16-lunch-1',
              kind: 'dish',
              refId: 'rec-turkey-patties',
              plannedServings: 1,
              plannedTime: '13:30'
            },
            {
              id: 'plan-16-lunch-2',
              kind: 'dish',
              refId: 'rec-cooked-buckwheat',
              plannedServings: 1
            }
          ],
          dinner: [
            {
              id: 'plan-16-dinner-1',
              kind: 'dish',
              refId: 'rec-baked-fish',
              plannedServings: 1
            },
            {
              id: 'plan-16-dinner-2',
              kind: 'dish',
              refId: 'rec-salad',
              plannedServings: 1
            }
          ],
          snack: [
            {
              id: 'plan-16-snack-1',
              kind: 'product',
              refId: 'prod-greek-yogurt',
              plannedGrams: 200,
              plannedTime: '16:30',
              notes: 'Перекус после работы.'
            }
          ]
        },
        mealComponents: {
          breakfast: [
            {
              id: 'cmp-16-breakfast-1',
              type: 'main',
              recipeRef: 'rec-omelet',
              portion: '1 порция'
            }
          ],
          lunch: [
            {
              id: 'cmp-16-lunch-1',
              type: 'main',
              recipeRef: 'rec-turkey-patties',
              portion: '1 порция'
            },
            {
              id: 'cmp-16-lunch-2',
              type: 'side',
              recipeRef: 'rec-cooked-buckwheat',
              portion: '1 порция'
            }
          ],
          dinner: [
            {
              id: 'cmp-16-dinner-1',
              type: 'main',
              recipeRef: 'rec-baked-fish',
              portion: '1 порция'
            },
            {
              id: 'cmp-16-dinner-2',
              type: 'salad',
              recipeRef: 'rec-salad',
              portion: '1 порция',
              extra: true
            }
          ],
          snack: [
            {
              id: 'cmp-16-snack-1',
              type: 'snack',
              recipeRef: 'rec-yogurt-dessert',
              portion: '1 порция',
              notes: 'Если нужен сладкий вариант.'
            }
          ]
        },
        mealTimes: {
          breakfast: '08:00',
          lunch: '13:30',
          dinner: '19:00',
          snack: '16:30'
        },
        workoutsPlan: [
          {
            id: 'plan-16-workout-1',
            timeOfDay: 'morning',
            protocolRef: 'proto-r10-warmup',
            isRequired: true,
            kind: 'workout',
            plannedTime: '08:15'
          },
          {
            id: 'plan-16-movement-1',
            timeOfDay: 'day',
            plannedMinutes: 10,
            kind: 'movement',
            movementActivityRef: 'move-march',
            plannedTime: '12:30'
          },
          {
            id: 'plan-16-workout-2',
            timeOfDay: 'evening',
            protocolRef: 'proto-s0-str',
            isRequired: true,
            kind: 'workout',
            plannedTime: '18:30'
          }
        ],
        plannedSteps: 8000,
        activityTargets: {
          steps: 8000,
          trainingMinutes: 30,
          movementMinutes: 15,
          coefficient: 1.1
        },
        nutritionTargets: {
          kcal: 1800,
          protein: 130,
          fat: 60,
          carb: 180,
          meals: 3
        },
        requirements: {
          requireWeight: true,
          requireWaist: false,
          requirePhotos: ['front'],
          smokingTargetMax: 5,
          kcalTarget: 1800,
          sleepWakeTarget: '07:30',
          sleepDurationTargetMinutes: 450
        },
        notes: 'Стартовый день с фокусом на разминку и базовое питание.'
      },
      {
        id: 'day-2026-01-17',
        date: '2026-01-17',
        periodId: 'period-s0',
        tasks: [
          {
            id: 'task-17-strength',
            templateRef: 'tpl-strength',
            status: 'planned',
            assignedRefs: [{ kind: 'protocol', refId: 'proto-s0-str' }],
            target: { rounds: 2 },
            timeOfDay: 'evening'
          },
          {
            id: 'task-17-smoking',
            templateRef: 'tpl-smoking',
            status: 'planned',
            assignedRefs: [
              { kind: 'rule', refId: 'rule-delay-cigarette' },
              { kind: 'rule', refId: 'rule-water-breaths' }
            ],
            target: { max: 5 },
            timeOfDay: 'day'
          }
        ],
        mealsPlan: {
          breakfast: [
            {
              id: 'plan-17-breakfast-1',
              kind: 'dish',
              refId: 'rec-omelet',
              plannedServings: 1,
              plannedTime: '08:10'
            }
          ],
          lunch: [
            {
              id: 'plan-17-lunch-1',
              kind: 'dish',
              refId: 'rec-baked-chicken',
              plannedServings: 1,
              plannedTime: '13:20'
            },
            {
              id: 'plan-17-lunch-2',
              kind: 'dish',
              refId: 'rec-cooked-rice',
              plannedServings: 1
            }
          ],
          dinner: [
            {
              id: 'plan-17-dinner-1',
              kind: 'dish',
              refId: 'rec-baked-fish',
              plannedServings: 1
            },
            {
              id: 'plan-17-dinner-2',
              kind: 'dish',
              refId: 'rec-salad',
              plannedServings: 1,
              plannedTime: '19:00'
            }
          ],
          snack: [
            {
              id: 'plan-17-snack-1',
              kind: 'free',
              title: 'Фруктовый перекус',
              plannedKcal: 180,
              plannedProtein: 3,
              plannedFat: 1,
              plannedCarb: 40,
              plannedTime: '16:00',
              notes: 'Выбрать сезонный фрукт.'
            }
          ]
        },
        mealComponents: {
          breakfast: [
            {
              id: 'cmp-17-breakfast-1',
              type: 'main',
              recipeRef: 'rec-omelet',
              portion: '1 порция'
            }
          ],
          lunch: [
            {
              id: 'cmp-17-lunch-1',
              type: 'main',
              recipeRef: 'rec-baked-chicken',
              portion: '1 порция'
            },
            {
              id: 'cmp-17-lunch-2',
              type: 'side',
              recipeRef: 'rec-cooked-rice',
              portion: '1 порция'
            }
          ],
          dinner: [
            {
              id: 'cmp-17-dinner-1',
              type: 'main',
              recipeRef: 'rec-baked-fish',
              portion: '1 порция'
            },
            {
              id: 'cmp-17-dinner-2',
              type: 'salad',
              recipeRef: 'rec-salad',
              portion: '1 порция'
            }
          ],
          snack: [
            {
              id: 'cmp-17-snack-1',
              type: 'snack',
              portion: '1 порция',
              notes: 'Свободный вариант.'
            }
          ]
        },
        mealTimes: {
          breakfast: '08:10',
          lunch: '13:20',
          dinner: '19:00',
          snack: '16:00'
        },
        workoutsPlan: [
          {
            id: 'plan-17-workout-1',
            timeOfDay: 'morning',
            protocolRef: 'proto-r10-warmup',
            isRequired: true,
            kind: 'workout',
            plannedTime: '08:30'
          },
          {
            id: 'plan-17-movement-1',
            timeOfDay: 'day',
            plannedMinutes: 15,
            kind: 'movement',
            movementActivityRef: 'move-stairs',
            plannedTime: '12:40'
          },
          {
            id: 'plan-17-workout-2',
            timeOfDay: 'evening',
            protocolRef: 'proto-s0-str',
            isRequired: true,
            kind: 'workout',
            plannedTime: '18:40'
          }
        ],
        plannedSteps: 9000,
        activityTargets: {
          steps: 9000,
          trainingMinutes: 35,
          movementMinutes: 20,
          coefficient: 1.15
        },
        nutritionTargets: {
          kcal: 1800,
          protein: 130,
          fat: 60,
          carb: 180,
          meals: 3
        },
        requirements: {
          requireWeight: false,
          requireWaist: true,
          requirePhotos: ['front', 'side'],
          smokingTargetMax: 5,
          kcalTarget: 1800,
          sleepWakeTarget: '07:30',
          sleepDurationTargetMinutes: 450
        },
        notes: 'Добавлен свободный перекус и тренировка лестницы.'
      },
      {
        id: 'day-2026-01-18',
        date: '2026-01-18',
        periodId: 'period-s0',
        tasks: [
          {
            id: 'task-18-measure',
            templateRef: 'tpl-measurement',
            status: 'planned',
            target: { weight: 'kg', waist: 'cm' },
            timeOfDay: 'morning'
          },
          {
            id: 'task-18-move',
            templateRef: 'tpl-movement',
            status: 'planned',
            target: { minutes: 20 },
            timeOfDay: 'day'
          }
        ],
        mealsPlan: {
          breakfast: [
            {
              id: 'plan-18-breakfast-1',
              kind: 'product',
              refId: 'prod-eggs',
              plannedGrams: 150,
              plannedTime: '08:15',
              notes: 'Варёные яйца.'
            }
          ],
          lunch: [
            {
              id: 'plan-18-lunch-1',
              kind: 'dish',
              refId: 'rec-turkey-patties',
              plannedServings: 1,
              plannedTime: '13:00'
            },
            {
              id: 'plan-18-lunch-2',
              kind: 'dish',
              refId: 'rec-cooked-buckwheat',
              plannedServings: 1
            }
          ],
          dinner: [
            {
              id: 'plan-18-dinner-1',
              kind: 'dish',
              refId: 'rec-baked-chicken',
              plannedServings: 1
            },
            {
              id: 'plan-18-dinner-2',
              kind: 'dish',
              refId: 'rec-salad',
              plannedServings: 1,
              plannedTime: '19:10'
            }
          ],
          snack: [
            {
              id: 'plan-18-snack-1',
              kind: 'product',
              refId: 'prod-apple',
              plannedGrams: 150,
              plannedTime: '16:10'
            },
            {
              id: 'plan-18-snack-2',
              kind: 'cheat',
              title: 'Тёмный шоколад',
              plannedKcal: 110,
              plannedProtein: 2,
              plannedFat: 8,
              plannedCarb: 10,
              cheatCategory: 'sweets',
              nutritionTags: ['cheat', 'snack'],
              plannedTime: '20:30'
            }
          ]
        },
        mealComponents: {
          breakfast: [
            {
              id: 'cmp-18-breakfast-1',
              type: 'main',
              portion: '2 яйца'
            }
          ],
          lunch: [
            {
              id: 'cmp-18-lunch-1',
              type: 'main',
              recipeRef: 'rec-turkey-patties',
              portion: '1 порция'
            },
            {
              id: 'cmp-18-lunch-2',
              type: 'side',
              recipeRef: 'rec-cooked-buckwheat',
              portion: '1 порция'
            }
          ],
          dinner: [
            {
              id: 'cmp-18-dinner-1',
              type: 'main',
              recipeRef: 'rec-baked-chicken',
              portion: '1 порция'
            },
            {
              id: 'cmp-18-dinner-2',
              type: 'drink',
              recipeRef: 'rec-smoothie',
              portion: '250 мл'
            }
          ],
          snack: [
            {
              id: 'cmp-18-snack-1',
              type: 'dessert',
              recipeRef: 'rec-yogurt-dessert',
              portion: '1 порция',
              extra: true
            }
          ]
        },
        mealTimes: {
          breakfast: '08:15',
          lunch: '13:00',
          dinner: '19:10',
          snack: '16:10'
        },
        workoutsPlan: [
          {
            id: 'plan-18-workout-1',
            timeOfDay: 'morning',
            protocolRef: 'proto-r10-warmup',
            isRequired: true,
            kind: 'workout',
            plannedTime: '08:40'
          },
          {
            id: 'plan-18-movement-1',
            timeOfDay: 'day',
            plannedMinutes: 20,
            kind: 'movement',
            movementActivityRef: 'move-run',
            plannedTime: '12:30'
          }
        ],
        plannedSteps: 7000,
        activityTargets: {
          steps: 7000,
          movementMinutes: 20,
          distanceKm: 3,
          coefficient: 1
        },
        nutritionTargets: {
          kcal: 1750,
          protein: 125,
          fat: 55,
          carb: 170,
          meals: 3
        },
        requirements: {
          requireWeight: false,
          requireWaist: false,
          requirePhotos: [],
          smokingTargetMax: 4,
          kcalTarget: 1750,
          sleepWakeTarget: '07:00',
          sleepDurationTargetMinutes: 435
        },
        notes: 'День с измерениями и читмилом.'
      }
    ]
  },
  logs: {
    foodDays: [],
    training: [],
    movementSessions: [],
    movementDays: [],
    smoking: [],
    water: [],
    drinks: [],
    weight: [],
    waist: [],
    sleep: [],
    photos: []
  },
  presets: {
    portions: [
      { label: '1 порция', grams: 200 },
      { label: '1/2 тарелки', grams: 150 },
      { label: '2 котлеты', grams: 220 }
    ],
    dishPortions: [
      { label: '1 порция', servings: 1 },
      { label: '1/2 порции', servings: 0.5 },
      { label: '1.5 порции', servings: 1.5 },
      { label: '1 тарелка', servings: 1 },
      { label: 'маленькая порция', servings: 0.7 }
    ]
  }
};
